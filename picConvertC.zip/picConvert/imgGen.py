#!/usr/bin/python
# -*- coding: UTF-8 -*-
import json
import os
import shutil
import codecs
import numpy as np
import copy
import cv2

import string
printable = string.ascii_letters + string.digits + string.punctuation + ' '
def byte2str(bytes):
	return "".join(map(chr, bytes))
	'''
	line = ''
	for x in bytes:
		c = chr(x)
		if c in printable:
			line += c
		else:
			line += '.'
	return line
	'''
def prnHex(content):
	print('    ', end = '  ')
	for i in range(16):
		print("{:02X}".format(i), end = ' ')
	row = 0
	for i, data in enumerate(content):
		if (i % 16) == 0:
			print('\n{:04X}'.format(row), end = '  ')
		print('{:02X}'.format(data), end = ' ')
		if (i % 16) == 15:
			line = content[row*16:i+1]
			print('  ', byte2str(line), end = '|')
			row += 1
	for j in range(15 - (i % 16)):
		print('  |', end = '')
	line = content[row*16:i+1]
	print('  ', byte2str(line), end = '|\n')

	
OUT_PATH = 'out\\'
height	= 16
width	= 16

def saveImg(name):
	cv2.imshow('image',img)
#	cv2.waitKey(0)
	path = OUT_PATH + name + '.bmp'
	print('saveImg =', path)
	cv2.imwrite(path , img)

def prnFile(name):
	path = OUT_PATH + name
	print('prnFile =', path)
	f = open(path, 'rb')
	content = f.read()
	prnHex(content)
	
img = np.zeros((height, width, 3), np.uint8)
saveImg('1')

img[:]	= (0,0,255)
saveImg('2')

cv2.destroyAllWindows()

prnFile('2.bmp')

#img = cv2.imread('test.jpg')
#im_gray = cv2.imread('data/src/lena.jpg', cv2.IMREAD_GRAYSCALE)
#print(img.shape)
