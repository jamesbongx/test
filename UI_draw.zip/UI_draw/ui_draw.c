
#include "ui_font.h"
#include "ui.h"
#include "ui_lcd.h"
#include "ui_draw.h"
#include "oled_ssd1317.h"

#if UI_DRAW_DEBUG_EN
#define UI_DRAW_DEBUG(fmt,...)	do{ GUI_DEBUG("UI_DRAW[%s][%d]: ", __FUNCTION__, __LINE__); GUI_DEBUG(fmt, ##__VA_ARGS__); }while(0)
#else
#define UI_DRAW_DEBUG(fmt,...)	do{ }while(0)
#endif


/***********************************************************
** function : draw point
** in :
** x, y :coordinate
** return
** void
** author : by xulianghuan
***********************************************************/
static void ui_draw_point(int x, int y, ui_color_t color)
{
	int pos;
	uint8_t *p_lcd_fbuf;
	uint8_t const bitm[] = {0x01, 0x02,0x04,0x08,0x10,0x20,0x40,0x80};
	uint8_t const rebitm[] = {(uint8_t)~0x01,
	                          (uint8_t)~0x02,
	                          (uint8_t)~0x04,
	                          (uint8_t)~0x08,
	                          (uint8_t)~0x10,
	                          (uint8_t)~0x20,
	                          (uint8_t)~0x40,
	                          (uint8_t)~0x80};

	if((x < 0)||(y < 0)||(x >= LCD_WIDTH)||(y >= LCD_HEIGHT))
	{
		return ;
	}
	p_lcd_fbuf = g_lcd_framebuff;

	#ifdef UI_WIN32
	pos = 7 - (x % 8); //the first point is high bit.
	p_lcd_fbuf += (x + y * LCD_WIDTH) / 8;
	#else
	pos = (LCD_WIDTH - 1 - x) % 8; //the first point is high bit.
	p_lcd_fbuf += (LCD_WIDTH - 1 - x)/8 * LCD_WIDTH + (LCD_HEIGHT - 1 - y);
	#endif

	if(color == UI_COLOR_WHITE)
	{
		*p_lcd_fbuf |= bitm[pos];
	}
	else
	{
		*p_lcd_fbuf &= rebitm[pos];
	}
}

/***********************************************************
** function : draw horizontal line
** in :
** x, y :coordinate, len :line len
** return
** 0:success, 1:failed.
** author : by xulianghuan
***********************************************************/
static void _ui_draw_horizontal_line(int x, int y, int len, ui_color_t color)
{
	//draw line
	while(len > 0)
	{
		ui_draw_point(x + len - 1, y, color);
		len--;
	}
}

/***********************************************************
** function : draw horizontal line
** in :
** x, y :coordinate, len :line len
** return
** 0:success, 1:failed.
** author : by xulianghuan
***********************************************************/
void ui_draw_horizontal_line(int x, int y, int len)
{
	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	ui_color_t color = ui_get_color();

	_ui_draw_horizontal_line(x, y, len, color);

	ui_set_display_x_pos(x+len);
	ui_set_display_y_pos(y);
}

/***********************************************************
** function : draw vertical line
** in :
** x, y :coordinate, len :line len
** return
** void
** author : by xulianghuan
***********************************************************/
static void _ui_draw_vertical_line(int x, int y, int len, ui_color_t color)
{
	//draw line
	while(len > 0)
	{
		ui_draw_point(x, y + len - 1, color);
		len--;
	}
}

/***********************************************************
** function : draw vertical line
** in :
** x, y :coordinate, len :line len
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_vertical_line(int x, int y, int len)
{
	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	ui_color_t color = ui_get_color();

	_ui_draw_vertical_line(x, y, len, color);

	ui_set_display_x_pos(x);
	ui_set_display_y_pos(y+len);
}

/***********************************************************
** function : draw line
** in :
** x0, y0, x1, y1 :start coordinate and end coordinate
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_line(int x0, int y0, int x1, int y1)
{
	int t, distance;
	int incx, incy;
	ui_color_t color = ui_get_color();
	int x = 0, y = 0, delta_x, delta_y;

	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	ui_set_display_x_pos(x1);
	ui_set_display_y_pos(y1);

	delta_x = x1 - x0;
	delta_y = y1 - y0;

	if(delta_x > 0)
	{
		incx = 1;
	}
	else if(delta_x == 0)
	{
		_ui_draw_vertical_line(x0, y0, y1, color);
		return;
	}
	else
	{
		incx = -1;
	}

	if(delta_y > 0)
	{
		incy = 1;
	}
	else if(delta_y == 0)
	{
		_ui_draw_horizontal_line(x0, y0, x1, color);
		return;
	}
	else
	{
		incy = -1;
	}

	delta_x = UI_ABS(delta_x);
	delta_y = UI_ABS(delta_y);

	if(delta_x > delta_y)
	{
		distance = delta_x;
	}
	else
	{
		distance = delta_y;
	}

	ui_draw_point(x0, y0, color);

	/*DrawLine*/
	for(t = 0; t <= distance + 1; t++)
	{
		ui_draw_point(x0, y0, color);
		x += delta_x;
		y += delta_y;

		if(x > distance)
		{
			x -= distance;
			x0 += incx;
		}

		if(y > distance)
		{
			y -= distance;
			y0 += incy;
		}
	}
}

/***********************************************************
** function : draw rectangle
** in :
** x0, y0, x1, y1 :start up left coordinate and end right down coordinate
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_rectangle(int x0, int y0, int x1, int y1)
{
	ui_color_t color;

	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	color = ui_get_color();

	if((x0 > x1) || (y0 > y1))
	{
		UI_DRAW_DEBUG("retangle coordnate illagel.\r\n");
		return;
	}

	ui_set_display_x_pos(x1);
	ui_set_display_y_pos(y1);

	_ui_draw_horizontal_line(x0, y0, x1 - x0 + 1, color);
	_ui_draw_horizontal_line(x0, y1, x1 - x0 + 1, color);
	_ui_draw_vertical_line(x0, y0, y1 - y0 + 1, color);
	_ui_draw_vertical_line(x1, y0, y1 - y0 + 1, color);
}

/***********************************************************
** function : fill rectangle
** in :
** x0, y0, x1, y1 :start up left coordinate and end right down coordinate
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_fill_rectangle(int x0, int y0, int x1, int y1)
{
	int x_width = x1 - x0;
	int y_height = y1 - y0;
	ui_color_t color;

	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	color = ui_get_color();

	if((x0 > x1) || (y0 > y1))
	{
		UI_DRAW_DEBUG("retangle coordnate illagel.\r\n");
		return;
	}

	ui_set_display_x_pos(x1);
	ui_set_display_y_pos(y1);

	if(x_width > y_height)
	{
		for(;y0 <= y1; y0++)
		{
			_ui_draw_horizontal_line(x0, y0, x_width + 1, color);
		}
	}
	else{
		for(;x0 <= x1; x0++)
		{
			_ui_draw_vertical_line(x0, y0, y_height + 1, color);
		}
	}
}

void ui_draw_clear_rectangle(int x0, int y0, int x1, int y1)
{
	ui_color_t color;

	color = ui_get_color();
	ui_set_color(UI_COLOR_BLACK);
	ui_draw_fill_rectangle(x0, y0, x1, y1);
	ui_set_color(color);
}

/***********************************************************
** function : clear screen
** in :
** void
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_clear_screen(void)
{
	ui_color_t bg_color;

	bg_color = ui_get_background_color();
	ui_lcd_clear(bg_color);

	ui_set_display_x_pos(0);
	ui_set_display_y_pos(0);
}

/***********************************************************
** function : draw buffer
** in :
** x, y :coordinate, buffer_x_size, buffer_y_size :buffer size
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_buffer(const uint8_t *ptr, int is_font, int x, int y, int buffer_x_size, int buffer_y_size, unsigned char x_align_flag)
{
	ui_color_t color, inv_color;
	const uint8_t *p_pic = ptr;
	const uint8_t bitm[] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
	int x_s,x_e,y_s,y_e,x0,y0;
	unsigned short x_pos,y_pos,x_offset,y_offset;
	unsigned short x_align_size;

	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	/* 1. adjust the argument. */
	if((buffer_x_size > LCD_WIDTH) || (buffer_y_size > LCD_HEIGHT))
		return ;

	x_s = x;
	x_e = x + buffer_x_size;
	y_s = y;
	y_e = y + buffer_y_size;
	if((x_e < 0) || (x_s >= LCD_WIDTH) || (y_e < 0) || (y_s >= LCD_HEIGHT))
		return ;

	ui_set_display_x_pos(x+buffer_x_size);
	ui_set_display_y_pos(y+buffer_y_size);

	if(x_s < 0)
	{
		x_pos = -x_s;
		x_s = 0;
	}
	else{
		x_pos = 0;
	}
	if(x_e > LCD_WIDTH)
	{
		x_e = LCD_WIDTH;
	}

	if(y_s < 0)
	{
		y_pos = -y_s;
		y_s = 0;
	}
	else{
		y_pos = 0;
	}
	if(y_e > LCD_WIDTH)
	{
		y_e = LCD_WIDTH;
	}

	color = ui_get_color();
	if(!is_font)
	{
		color = UI_COLOR_WHITE;
	}

	if(color == UI_COLOR_BLACK)
	{
		inv_color = UI_COLOR_WHITE;
	}
	else
	{
		inv_color = UI_COLOR_BLACK;
	}

	x_align_size = x_align_flag > 0 ? ((buffer_x_size+7)/8)*8 : buffer_x_size;
	y_offset = y_pos * x_align_size;
	for(y0 = y_s;y0 < y_e;y0++)
	{
		x_offset = x_pos;
		for(x0 = x_s; x0 < x_e; x0++,x_offset++)
		{
			p_pic = &ptr[(y_offset + x_offset)/8];
			if(*p_pic & bitm[x_offset % 8])
			{
				ui_draw_point(x0, y0, color);
			}
			else
			{
				if(is_font && (ui_get_draw_mode() == UI_DRAW_MODE_XOR))
				{
					continue;
				}

				ui_draw_point(x0, y0, inv_color);
			}
		}

		y_offset += x_align_size;
	}
}

/***********************************************************
** function : draw picture
** in :
** x, y :coordinate, p_bitmap :pointer of pictrue.
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_picture(const ui_bitmap_t *p_bitmap, int x, int y)
{
	ui_draw_buffer(p_bitmap->p_data, 0, x, y, p_bitmap->x_size, p_bitmap->y_size, p_bitmap->x_align_flag);
}

/***********************************************************
** function : draw circle
** in :
** x, y :coordinate, r :radius.
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_circle(int x, int y, int r)
{
	int a,b;
	float c;
	ui_color_t color;

	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	ui_set_display_x_pos(x+r);
	ui_set_display_y_pos(y+r);

	color = ui_get_color();

	a = 0;
	b = r;
	c = 3.0f - 2.0f * r;
	color = ui_get_color();

	while(a < b)
	{
		ui_draw_point(x + a, y + b, color);
		ui_draw_point(x - a, y + b, color);
		ui_draw_point(x + a, y - b, color);
		ui_draw_point(x - a, y - b, color);

		ui_draw_point(x + b, y + a, color);
		ui_draw_point(x - b, y + a, color);
		ui_draw_point(x + b, y - a, color);
		ui_draw_point(x - b, y - a, color);

		if(c < 0)
		{
			c = c + 4 * a + 6;
		}
		else
		{
			c = c + 4*(a - b) + 10;
			b -= 1;
		}

		a = a + 1;
	}

	if(a == b)
	{
		ui_draw_point(x + a, y + b, color);
		ui_draw_point(x - a, y + b, color);
		ui_draw_point(x + a, y - b, color);
		ui_draw_point(x - a, y + b, color);

		ui_draw_point(x + b, y + a, color);
		ui_draw_point(x - b, y + a, color);
		ui_draw_point(x + b, y - a, color);
		ui_draw_point(x - b, y - a, color);
	}
}

/***********************************************************
** function : fill circle
** in :
** x0, y0 :coordinate, r :radius.
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_draw_fill_circle(int x0, int y0, int r)
{
	int x = 0;
	int y = r;
	int f = 1 - r;
	int ddf_x = 1;
	ui_color_t color;
	int ddf_y = -2 * r;

	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	color = ui_get_color();
	_ui_draw_vertical_line(x0, y0 - r, 2 * r + 1, color);

	while (x < y)
	{
		if (f >= 0)
		{
			y--;
			ddf_y += 2;
			f += ddf_y;
		}

		x++;
		ddf_x += 2;
		f += ddf_x;

		_ui_draw_vertical_line(x0 + x, y0 - y, 2 * y + 1, color);
		_ui_draw_vertical_line(x0 + y, y0 - x, 2 * x + 1, color);

		_ui_draw_vertical_line(x0 - x, y0 - y, 2 * y + 1, color);
		_ui_draw_vertical_line(x0 - y, y0 - x, 2 * x + 1, color);
	}
}

void ui_draw_progress_bar(unsigned int max_value, unsigned int current_value)
{
	unsigned int offset = (LCD_HEIGHT - (max_value - 1)*7)/2;

	for(unsigned int i = 0;i < max_value;i++)
	{
		if(i == current_value)
		{
		#if 0
			ui_draw_point(LCD_WIDTH - 6, offset + i*7, UI_COLOR_WHITE);
			ui_draw_point(LCD_WIDTH - 6, offset + i*7-1, UI_COLOR_WHITE);
			ui_draw_point(LCD_WIDTH - 6, offset + i*7+1, UI_COLOR_WHITE);
			ui_draw_point(LCD_WIDTH - 7, offset + i*7, UI_COLOR_WHITE);
			ui_draw_point(LCD_WIDTH - 5, offset + i*7, UI_COLOR_WHITE);
		#else
			//ui_draw_fill_rectangle(LCD_WIDTH - 6, offset + i*7 - 1, LCD_WIDTH - 3, offset + i*7 + 2);
			ui_draw_fill_rectangle(LCD_WIDTH - 6, offset + i*7, LCD_WIDTH - 3, offset + i*7 + 1);
		#endif
		}
		else{
		#if 0
			ui_draw_point(LCD_WIDTH - 6, offset + i*7, UI_COLOR_WHITE);
		#else
			ui_draw_fill_rectangle(LCD_WIDTH - 5, offset + i*7, LCD_WIDTH - 4, offset + i*7 + 1);
		#endif
		}
	}
}

void ui_draw_battery(int x, int y, unsigned char battery_capacity)
{
	unsigned int x_len = 12, y_len = 6;

	ui_draw_fill_rectangle(x, y+2, x+1, y+y_len-2);
	ui_draw_rectangle(x+2, y, x+x_len+2, y+y_len);

	if(battery_capacity > 10)
	{
		ui_draw_fill_rectangle(x+2+(x_len - (x_len*battery_capacity+50)/100), y, x+x_len+2, y+y_len);
	}
	else{
		ui_draw_vertical_line(x+2+(x_len/2), y+2, 2);
		ui_draw_vertical_line(x+2+1+(x_len/2), y+3, 2);
	}
}


