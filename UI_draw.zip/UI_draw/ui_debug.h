#ifndef UI_DEBUG_H
#define UI_DEBUG_H

#include "debug_info.h"

#if GUI_DEBUG_EN == 0
#define UI_DEBUG_EN        (0)
#define UI_FONT_DEBUG_EN   (0)
#define UI_DRAW_DEBUG_EN   (0)
#else
#define UI_DEBUG_EN        (1)
#define UI_FONT_DEBUG_EN   (1)
#define UI_DRAW_DEBUG_EN   (1)
#endif


#endif /* UI_DEBUG_H */

