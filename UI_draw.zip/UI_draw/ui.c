
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ui.h"
#include "ui_lcd.h"
#include "ui_font.h"
#include "gui_font_unicode.h"
#include "oled_ssd1317.h"

#if UI_DEBUG_EN
#define UI_DEBUG(fmt,...)	do{ GUI_DEBUG("UI[%s][%d]: ", __FUNCTION__, __LINE__); GUI_DEBUG(fmt, ##__VA_ARGS__); }while(0)
#else
#define UI_DEBUG(fmt,...)	do{ }while(0)
#endif

static char ui_is_inited = 0;
static ui_color_t current_color = UI_COLOR_WHITE;
static ui_color_t background_color = UI_COLOR_BLACK;
static ui_draw_mode_t current_draw_mode = UI_DRAW_MODE_NORMAL;
static ui_point_t current_display_point = {0};


/***********************************************************
** function : set draw mode
** in :
** bg_color :new color
** return
** old color
** author : by xulianghuan
***********************************************************/
ui_draw_mode_t ui_set_draw_mode(ui_draw_mode_t mode)
{
	ui_draw_mode_t old_mode;

	old_mode = current_draw_mode;
	current_draw_mode = mode;

	return old_mode;
}

/***********************************************************
** function : get draw mode
** in :
** void
** return
** current color
** author : by xulianghuan
***********************************************************/
ui_draw_mode_t ui_get_draw_mode(void)
{
	ui_draw_mode_t draw_mode;

	draw_mode = current_draw_mode;

	return draw_mode;
}

/***********************************************************
** function : set color
** in :
** bg_color :new color
** return
** old color
** author : by xulianghuan
***********************************************************/
ui_color_t ui_set_color(ui_color_t color)
{
	ui_color_t old_color;

	old_color = current_color;
	current_color = color;

	return old_color;
}

/***********************************************************
** function : get color
** in :
** void
** return
** current color
** author : by xulianghuan
***********************************************************/
ui_color_t ui_get_color(void)
{
	ui_color_t color;

	color = current_color;

	return color;
}

/***********************************************************
** function : set background color
** in :
** bg_color :new background color
** return
** old background color
** author : by xulianghuan
***********************************************************/
ui_color_t ui_set_background_color(ui_color_t bg_color)
{
	ui_color_t old_bg_color;

	old_bg_color = background_color;
	background_color = bg_color;

	return old_bg_color;
}

/***********************************************************
** function : get background color
** in :
** void
** return
** background color
** author : by xulianghuan
***********************************************************/
ui_color_t ui_get_background_color(void)
{
	ui_color_t bg_color;

	bg_color = background_color;

	return bg_color;
}

/***********************************************************
** function : set display x position
** in :
** x_pos : x position
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_set_display_x_pos(signed short x)
{
	current_display_point.x = x;
}

/***********************************************************
** function : set display y position
** in :
** x_pos : x position
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_set_display_y_pos(signed short y)
{
	current_display_point.y = y;
}

/***********************************************************
** function : get display x position
** in :
** void
** return
** x position
** author : by xulianghuan
***********************************************************/
signed short ui_get_display_x_pos(void)
{
	return current_display_point.x;
}

/***********************************************************
** function : get display y position
** in :
** void
** return
** y position
** author : by xulianghuan
***********************************************************/
signed short ui_get_display_y_pos(void)
{
	return current_display_point.y;
}

char ui_init_state(void)
{
	return ui_is_inited ;
}

/***********************************************************
** function : ui init
** in :
** void
** return
** void
** author : by xulianghuan
***********************************************************/
void ui_init(void)
{
	if(ui_is_inited)
	{
		UI_DEBUG("ui is inited\r\n");
		return;
	}

	ui_set_draw_mode(UI_DRAW_MODE_XOR);
	ui_set_color(UI_COLOR_WHITE);
	ui_set_background_color(UI_COLOR_BLACK);

#if 0
	//test_language();
	extern ui_bitmap_t test_pic_1_map;
	ui_draw_picture(&test_pic_1_map, 10, 10);
	GUI_HZ_DispStringAt(&FONT_GB2312_16x16, "1", 10, 45);

	extern ui_bitmap_t test_pic_2_map;
	ui_draw_picture(&test_pic_2_map, 50, 10);
	GUI_HZ_DispStringAt(&FONT_GB2312_16x16, "2", 50, 45);

	extern ui_bitmap_t test_pic_3_map;
	ui_draw_picture(&test_pic_3_map, 10, 65);
	GUI_HZ_DispStringAt(&FONT_GB2312_16x16, "3", 50, 80);

	GUI_DispStringAt(&FONT_GB2312_16x16, STRING_STEPS, 60, 80);

	update_to_lcd();
#endif

	ui_is_inited = 1;
}

void GUI_init(void)
{
	oled_init();
	ui_init();
}

void GUI_clear(void)
{
	ui_set_background_color(UI_COLOR_BLACK);
	ui_draw_clear_screen();

	update_to_lcd();
}

void display_updata_progress(unsigned char value)
{
	unsigned char x_len = LCD_WIDTH-5;
	char temp[20] = {0};

	ui_set_background_color(UI_COLOR_BLACK);
	ui_draw_clear_screen();

	snprintf(temp, sizeof(temp), "Updata %d%%", value);
	GUI_HZ_DispStringAt_Hcenter(&FONT_ASC7x13, temp, 0, 30, 0, 0);
	ui_draw_rectangle(5, 60, x_len, 70);
	ui_draw_fill_rectangle(5, 60, value*x_len/100, 70);

	update_to_lcd();
}


