#include "GUI_FONT_Unicode.h"
#include "ui_draw.h"
#include "ui_font.h"
#include "string.h"
#include "ui_lcd.h"
#include "debug_info.h"
#include "oled_ssd1317.h"


static unsigned short get_unicode_index(unsigned short unicode)  //�ö��ֲ����㷨
{
	unsigned int offset=0;

	if((unicode >=0x20)&&(unicode <= 0x7F))
	{
		offset = unicode - 0x20; //the ascii index.
	}
	else if(unicode<=0X9FA5)
	{
		if(unicode>=0X4E00)
			offset=(0x7F-0x20) + unicode-0X4E00;//0x1b87      //0X4E00,����ƫ�����
		else
			return 0x0;      //������ʾ���ַ��͸������ո����,��������
	}
	else if(unicode>0X9FA5)//�Ǳ�����
	{
		if(unicode<0XFF01||unicode>0XFF61)
			return 0x0;//û�ж�Ӧ����  //������ʾ���ַ��͸������ո����,��������
		offset=(0x7F-0x20) + unicode-0XFF01+0X9FA6-0X4E00;
	}

	return offset;
}

/***********************************************************
** function	: display string.
** argument	: font_info --> the font info struct point.
			  s --> the display string point.
			  x --> the display X position.
			  y --> the display Y position.
			  interval --> the between two char distance points.
			  auto_line --> 0: no line feed, 1: auto line feed when the line is full.
** return	: void.
** author	: by fengshanlong
***********************************************************/
static void _GUI_HZ_DispStringAt(const font_hz_struct *font_info, const char * s, int x, int y, unsigned int x_interval, unsigned int y_interval, unsigned char auto_line)
{
	unsigned int len = 0,num_bytes = 0;
	unsigned short unicode = 0,index = 0;
	unsigned int offset = 0,size = 0;
	int x0 = 0,y0 = 0;
	const unsigned char *map = NULL;
	unsigned char XSize,YSize;
	unsigned int font_interval = 0;

	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	if(NULL == font_info)
	{
		return ;
	}

	/* 0.init data. */
	x0 = x;
	y0 = y;
	len = strlen(s);
	XSize = font_info->asc_x_size;
	YSize = font_info->asc_y_size;

	//now start calculate the data & display it.
	while(len)
	{
		/* 0.handler the enter_key. */
		if(*s == '\n')
		{
			s++;
			len--;
			x0 = x;
			y0 += YSize + y_interval;
			continue;
		}

		/* 1.get unicode data. */
		num_bytes = ui_font_utf8_to_unicode((const unsigned char *)s, &unicode);
		if(num_bytes == 0)
			return ;
		s += num_bytes;
		len -= num_bytes;
		//GUI_DEBUG("len = %d\r\n", len);

		/* 2.get unicode index. */
		index = get_unicode_index(unicode);
		if(index < (0x7F-0x20)) //for ascii index.
		{
			XSize = font_info->asc_x_size;
			YSize = font_info->asc_y_size;
			size = font_info->asc_byteline * font_info->asc_y_size;
			//offset = index* size;
			offset = (index-(font_info->base_char-0x20))* size;
			//if ascii , so don't add interval.
			font_interval = 0;
		}
		else{//for hz.
			XSize = font_info->hz_x_size;
			YSize = font_info->hz_y_size;
			size = font_info->hz_byteline * font_info->hz_y_size;
			//offset = (0x7F - 0x20)*(font_info->asc_byteline * font_info->asc_y_size) +
			//		 (index - (0x7F - 0x20))*size;
			offset = (0x7F - font_info->base_char)*(font_info->asc_byteline * font_info->asc_y_size) +
					 (index - (0x7F - 0x20))*size;
			//if HZ , so add interval.
			font_interval = x_interval;
		}
		//GUI_DEBUG("utf8 num_bytes = %d, unicode index %d, offset = %d\r\n",num_bytes, index, offset);

		/* 3.get index unicode data. */
		if(offset < font_info->all_size)
		{
			map = &font_info->base_addr[offset];

			/* 4.draw picture map. */
			if((x0 >= LCD_WIDTH)||(x0 + XSize < 0)||(y0 >= LCD_HEIGHT)||(y0 + YSize < 0))
			{
				if(0 == auto_line)
				{
					continue ;
				}
				else{
					x0 = x;
					y0 += YSize + y_interval;
				}
			}
			ui_draw_buffer(map, 1, x0, y0, XSize, YSize, 1);
		}
		else{
			GUI_DEBUG(ERROR_"the font offset %d is over all_size %d\r\n",offset, font_info->all_size);
		}

		/* 5.add x offset. */
		x0 += XSize + font_interval;
	}
}

/***********************************************************
** function	: display string.
** argument	: font_info --> the font info struct point.
			  s --> the display string point.
			  x --> the display X position.
			  y --> the display Y position.
			  interval --> the between two char distance points.
** return	: void.
** author	: by fengshanlong
***********************************************************/
void GUI_HZ_DispStringAt(const font_hz_struct *font_info, const char * s, int x, int y, unsigned int x_interval, unsigned int y_interval)
{
	_GUI_HZ_DispStringAt(font_info, s, x, y, x_interval, y_interval, 0);
}

/***********************************************************
** function	: display string auto line feed if the line has full.
** argument	: font_info --> the font info struct point.
			  s --> the display string point.
			  x --> the display X position.
			  y --> the display Y position.
			  interval --> the between two char distance points.
** return	: void.
** author	: by fengshanlong
***********************************************************/
void GUI_HZ_DispStringAt_AutoLine(const font_hz_struct *font_info, const char * s, int x, int y, unsigned int x_interval, unsigned int y_interval)
{
	_GUI_HZ_DispStringAt(font_info, s, x, y, x_interval, y_interval, 1);
}

/***********************************************************
** function	: display string hcenter.
** argument	: font_info --> the font info struct point.
			  s --> the display string point.
			  x --> the display X position.
			  y --> the display Y position.
			  interval --> the between two char distance points.
** return	: void.
** author	: by fengshanlong
***********************************************************/
void GUI_HZ_DispStringAt_Hcenter(const font_hz_struct *font_info, const char * s, int x, int y, unsigned int x_interval, unsigned int y_interval)
{
	unsigned int len = 0,num_bytes = 0;
	unsigned int i = 0, j = 0;
	unsigned int point_len = 0;
	int x_offset = 0;
	char str[100];
	const char * p_string = str;
	unsigned int hz_num = 0;

	/* if oled don't open, so don't draw. */
	if(oled_get_status() == 0)
		return;

	if(NULL == font_info)
	{
		return ;
	}

	while(1)
	{
		if((s[i] != '\0')&&(s[i] != '\n'))
		{
			if(j < sizeof(str))
			{
				str[j] = s[i];
			}
			i++;
			j++;
			continue;
		}
		else{
			str[j] = '\0';
			j = 0;
			if(s[i] != '\0')
			{
				i++;
			}
			point_len = 0;
			hz_num = 0;
			p_string = str;
		}

		len = strlen(p_string);

		while(len)
		{
			num_bytes = ui_font_get_utf8_size(*p_string);
			if(num_bytes == 0)
				break;

			if(num_bytes == 1)
			{
				point_len += font_info->asc_x_size;
			}
			else{
				point_len += font_info->hz_x_size + x_interval;
				hz_num++;
			}

			p_string += num_bytes;
			len -= num_bytes;
		}

		/* if the font strings has hz, so delete one hz interval. */
		if(hz_num > 0)
		{
			point_len -= x_interval;
		}

		if(point_len <= LCD_WIDTH)
		{
			x_offset = (LCD_WIDTH - point_len)/2;
		}
		else{
			x_offset = 0;
		}
		GUI_HZ_DispStringAt(font_info, str, x_offset + x, y, x_interval, y_interval);

		if(s[i] == '\0')
		{
			break ;
		}
		else{
			if(hz_num > 0)
				y += font_info->hz_y_size + y_interval;
			else
				y += font_info->asc_y_size + y_interval;
		}
	}
}

unsigned int GUI_Get_String_len(const font_hz_struct *font_info, const char * s)
{
	unsigned int len = 0,num_bytes = 0;
	unsigned int point_len = 0;
	const char * p_string = s;

	if(NULL == font_info)
	{
		return 0;
	}

	len = strlen(p_string);

	while(len)
	{
		num_bytes = ui_font_get_utf8_size(*p_string);
		if(num_bytes == 0)
			break;

		if(num_bytes == 1)
		{
			point_len += font_info->asc_x_size;
		}
		else{
			point_len += font_info->hz_x_size;
		}

		p_string += num_bytes;
		len -= num_bytes;
	}

	return point_len;
}


void test_unicode(void)
{
	GUI_HZ_DispStringAt(&FONT_HZ16x16, TEST_UNICODE_STR_16x16, 0, 0, 0,0);
}


