
#ifndef UI_LCD_H
#define UI_LCD_H


#ifdef __cplusplus
extern "C"{
#endif

#define LCD_WIDTH  (96)
#define LCD_HEIGHT (96)

extern unsigned char g_lcd_framebuff[LCD_WIDTH * LCD_HEIGHT / 8];

void ui_lcd_clear(unsigned char color);
void update_to_lcd(void);

#ifdef __cplusplus
}
#endif


#endif /* UI_LCD_H */
