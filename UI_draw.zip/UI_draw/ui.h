
#ifndef MY_GUI_H
#define MY_GUI_H

#include <stdio.h>
#include <string.h>

#include "ui_debug.h"

#include "ui_draw.h"
#include "ui_font.h"

#ifdef __cplusplus
extern "C"{
#endif

typedef enum {
	UI_DRAW_MODE_XOR = 0,
	UI_DRAW_MODE_NORMAL,
}ui_draw_mode_t;

typedef struct {
	signed short x;
	signed short y;
}ui_point_t;

ui_draw_mode_t ui_set_draw_mode(ui_draw_mode_t mode);
ui_draw_mode_t ui_get_draw_mode(void);
ui_color_t ui_set_color(ui_color_t color);
ui_color_t ui_get_color(void);
ui_color_t ui_set_background_color(ui_color_t bg_color);
ui_color_t ui_get_background_color(void);
void ui_set_display_x_pos(signed short x);
void ui_set_display_y_pos(signed short y);
signed short ui_get_display_x_pos(void);
signed short ui_get_display_y_pos(void);

void ui_init(void);
char ui_init_state(void);
void GUI_init(void);
void GUI_clear(void);
void display_updata_progress(unsigned char value);


#ifdef __cplusplus
}
#endif


#endif
