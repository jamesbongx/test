#ifndef _GUI_FONT_UNICODE_H
#define _GUI_FONT_UNICODE_H

#define TEST_UNICODE_STR_16x16      "悦动(16x16)"

typedef struct
{
	const unsigned char *base_addr;	//the font buf base address.
	const unsigned int all_size;		//the font buf size.
	const unsigned int base_char;		//the base char value, the first char is ' '.
	const unsigned short asc_x_size;	//the font ascii char x size.
	const unsigned short asc_y_size;	//the font ascii char y size.
	const unsigned short asc_byteline;	//the font ascii char every line byte size.
	const unsigned short hz_x_size;	//the font hz char x size.
	const unsigned short hz_y_size;	//the font hz char y size.
	const unsigned short hz_byteline;	//the font hz char every line byte size.
	const unsigned char gb2312_flag; //0: unicode font(21000 hz), 1: gb2312 font(only 6768 hz).
}font_hz_struct;

extern const font_hz_struct FONT_HZ16x16;
extern const font_hz_struct FONT_ASC20x43;
extern const font_hz_struct FONT_GB2312_16x16;
extern const font_hz_struct FONT_ASC18x37;
extern const font_hz_struct FONT_ASC16x33;
extern const font_hz_struct FONT_ASC7x13;
extern const font_hz_struct FONT_ASC6x13;

extern void GUI_HZ_DispStringAt(const font_hz_struct *font_info, const char * s, int x, int y, unsigned int x_interval, unsigned int y_interval);
extern void GUI_HZ_DispStringAt_AutoLine(const font_hz_struct *font_info, const char * s, int x, int y, unsigned int x_interval, unsigned int y_interval);
extern void GUI_HZ_DispStringAt_Hcenter(const font_hz_struct *font_info, const char * s, int x, int y, unsigned int x_interval, unsigned int y_interval);
extern unsigned int GUI_Get_String_len(const font_hz_struct *font_info, const char * s);
extern void test_unicode(void);


#endif //_GUI_FONT_UNICODE_H

