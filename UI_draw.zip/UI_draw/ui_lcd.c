
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "debug_info.h"
#include "ui_lcd.h"
#include "string.h"
#include "oled_ssd1317.h"


unsigned char g_lcd_framebuff[LCD_WIDTH * LCD_HEIGHT / 8] = {0};

/***********************************************************
** function : clear the lcd framebuffer
** in :
** void
** return
** the pointer of lcd famebuffer.
** author : by xulianghuan
***********************************************************/
void ui_lcd_clear(unsigned char color)
{
	memset((void *)g_lcd_framebuff, color, sizeof(g_lcd_framebuff));
}

/***********************************************************
** function : update to lcd
** in :
** void
** return
** the pointer of lcd famebuffer.
** author : by xulianghuan
***********************************************************/
void update_to_lcd(void)
{
	uint8_t *p_temp_lcd_buff = g_lcd_framebuff;
#ifdef UI_WIN32
	int i, x, y;
	uint8_t temp;
	int x_size = LCD_WIDTH  / 8;
	int y_size = LCD_HEIGHT;

	for(y = 0; y < y_size; y++)
	{
		for(x = 0; x < x_size; x++)
		{
			temp = *p_temp_lcd_buff++;
			for(i = 0; i < 8; i++)
			{
				if(temp & 0x80)
					printf("+");
				else
					printf(" ");

				temp <<= 1;
			}
		}
		printf("\r\n");
	}
#else
	oled_update(p_temp_lcd_buff);
#endif
}

