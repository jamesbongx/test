
#include <stdint.h>

#include "ui.h"
#include "ui_font.h"


#if UI_FONT_DEBUG_EN
#define UI_FONT_DEBUG(fmt,...)	do{ GUI_DEBUG("UI_FONT[%s][%d]: ", __FUNCTION__, __LINE__); GUI_DEBUG(fmt, ##__VA_ARGS__); }while(0)
#else
#define UI_FONT_DEBUG(fmt,...)	do{ }while(0)
#endif


/***********************************************************
** function : get utf-8 size
** in :
** void
** return
** utf-8 size
** author : by xulianghuan
***********************************************************/
int ui_font_get_utf8_size(uint8_t ch)
{
	int utf8_size = (int)-1;
	uint8_t temp = ch & 0xf0;

	if(ch < 0x80)
	{
		return 1;
	}

	switch(temp)
	{
	case 0xf0:
		utf8_size = 4;
		break;
	case 0xe0:
		utf8_size = 3;
		break;
	default:
		if((temp & 0xc0) == 0xc0)
		{
			utf8_size = 2;
		}
		break;
	}

	return utf8_size;
}

/***********************************************************
** function : utf8 convert to unicode encode
** in :
** void
** return
** utf-8 size
** author : by xulianghuan
***********************************************************/
int ui_font_utf8_to_unicode(const uint8_t * p_char, uint16_t *uni_code)
{
	int utfbytes;
	uint8_t *p_output;
	uint8_t b1, b2, b3, b4;

	*uni_code = 0x0;
	p_output = (uint8_t *)uni_code;
	utfbytes = ui_font_get_utf8_size(*p_char);
	switch (utfbytes)
	{
	case 1:
		*p_output = *p_char;
		break;
	case 2:
		b1 = *p_char;
		b2 = *(p_char + 1);
		if ((b2 & 0xE0) != 0x80)
		{
			UI_FONT_DEBUG("(worng utf8 code.\r\n");
			return 0;
		}

		*p_output = (b1 << 6) + (b2 & 0x3F);
		*(p_output + 1) = (b1 >> 2) & 0x07;
		break;
	case 3:
		b1 = *p_char;
		b2 = *(p_char + 1);
		b3 = *(p_char + 2);
		if (((b2 & 0xC0) != 0x80) || ((b3 & 0xC0) != 0x80))
		{
			UI_FONT_DEBUG("(worng utf8 code.\r\n");
			return 0;
		}

		*p_output = (b2 << 6) + (b3 & 0x3F);
		*(p_output + 1) = (b1 << 4) + ((b2 >> 2) & 0x0F);
		break;
	case 4:
		b1 = *p_char;
		b2 = *(p_char + 1);
		b3 = *(p_char + 2);
		b4 = *(p_char + 3);
		if (((b2 & 0xC0) != 0x80) || ((b3 & 0xC0) != 0x80) || ((b4 & 0xC0) != 0x80))
		{
			UI_FONT_DEBUG("(worng utf8 code.\r\n");
			return 0;
		}

		*p_output = (b3 << 6) + (b4 & 0x3F);
		*(p_output + 1) = (b2 << 4) + ((b3 >> 2) & 0x0F);
		*(p_output + 2) = ((b1 << 2) & 0x1C)  + ((b2 >> 4) & 0x03);
		break;
	default:
		UI_FONT_DEBUG("(worng utf8 code.\r\n");
		return 0;
		break;
	}

	return utfbytes;
}


