picture name = xxx.png
=>
extern const unsigned char pic_xxx_data[];
extern const picture_info_struct pic_xxx_info;

unsigned char* ptr = pic_xxx_data;
for{unsigned int y = 0; y < pic_xxx_info.width){
	if(pic_xxx_info.alpha & 2){
		for(unsigned int x; x < pic_xxx_info.height;){
			unsigned int len = *(ptr++);
			unsigned int alpha, R, G, B;
			if(pic_xxx_info.alpha & 1){
				alpha = *(ptr++);
			}
			if(LCD is 565){
				int color = *(ptr++) << 8;
				color += *(ptr++);
				R = ((color >>11) << 3) & 0xFF;
				G = ((color >> 5) << 2) & 0xFF;
				B = ((color >> 0) << 3) & 0xFF;
			}else{
				R = *(ptr++);
				R = *(ptr++);
				B = *(ptr++);
			}
			if( is BGR ){
				R ^= B;
				B ^= R;
				R ^= B;
			}
			for(int i = 0; i < len; i++){
				img[y, x + i] = {R, G, B};
			}
			x += len;
		}
	}else{
		for(unsigned int x; x < pic_xxx_info.height; x++){
			unsigned int alpha, R, G, B;
			if(pic_xxx_info.alpha & 1){
				alpha = *(ptr++);
			}
			if(LCD is 565){
				int color = *(ptr++) << 8;
				color += *(ptr++);
				R = ((color >>11) << 3) & 0xFF;
				G = ((color >> 5) << 2) & 0xFF;
				B = ((color >> 0) << 3) & 0xFF;
			}else{
				R = *(ptr++);
				R = *(ptr++);
				B = *(ptr++);
			}
			if( is BGR ){
				R ^= B;
				B ^= R;
				R ^= B;
			}
		}
	}
}