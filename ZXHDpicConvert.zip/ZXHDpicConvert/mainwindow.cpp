
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QFile"
#include "stdio.h"
#include "QByteArray"
#include "QImage"
#include "QDir"
#include "QFileInfoList"
#include "QFileDialog"
#include "QMessageBox"
#include "QTextCodec"
bool getFshType(QString fname)
{
	return fname[0]=='E';
}
bool getAlphaType(QString fname)
{
	return fname[1]=='A';
}
bool getZipType(QString fname)
{
	return fname[2]=='R';
}
unsigned char colorFrm = 0; //888,565
unsigned char colorChl = 0; //RGB,BGR
unsigned int bufPtr;
int getColorSize(bool isAlpha)
{
	int len = 2;
	if (colorFrm==0) {
		len++;
	}
	if (isAlpha) {
		len++;
	}
	return len;
}
void saveColor(char*lineBuf, unsigned char alpha, unsigned char R, unsigned char G, unsigned char B, 
	unsigned int color, bool isAlpha)
{
	if (isAlpha) {
		lineBuf[bufPtr++] = alpha;
	}
	if (colorFrm==0) {
		lineBuf[bufPtr++] = R;
		lineBuf[bufPtr++] = G;
		lineBuf[bufPtr++] = B;
	}
	else {
		lineBuf[bufPtr++] = (color >> 8)&0xFF;
		lineBuf[bufPtr++] = (color >> 0)&0xFF;
	}
}
unsigned int convertLine(char*lineBuf, QImage*img, unsigned int y, bool isRLC, bool isAlpha)
{
	unsigned char alpha, R, G, B;
	unsigned int color, oldColor, len;

    bufPtr = 0;
	const uchar*it = img->constScanLine(y);
	int width = img->width();

	for (int x = 0; x<width; ++x) {
		R	=* (it++);
		G	=* (it++);
		B	=* (it++);
		if (colorChl==1) {
			R	^= B;
			B	^= R;
			R	^= B;
		}
		alpha =* (it++);
		color = ((R >> 3) << 11)+((G >> 2) << 5)+((B >> 3) << 0);
		if (isRLC) {
			if (colorFrm==1) {
				color = (R << 16)+(G << 8)+(B << 0);
			}
			if (isAlpha) {
				color += (alpha << 24);
			}
			if (x==0) {
				oldColor = color;
				len = 0;
				continue;
			}
			else if ((color==oldColor)&&(len<255)) {
				len++;
				continue;
			}
			else {
				lineBuf[bufPtr++] = len;
				len = 1;
				oldColor = color;
			}
		}
		saveColor(lineBuf, alpha, R, G, B, color, isAlpha);
	}
	if (isRLC) {
		lineBuf[bufPtr++] = len;
		saveColor(lineBuf, alpha, R, G, B, color, isAlpha);
	}
	return bufPtr;
}
QImage*loadImg(QString fname)
{
	QImage*img = new QImage();

	img->load(fname);
	return img;
}
#define MAX_LCD_WIDTH 320
#define MAX_LCD_HEIGHT 320
int convertImage(char*imgBuf, QImage*img, bool isRLC, bool isAlpha)
{
	unsigned int imgSize = 0;

	for (int y = 0; y<img->height(); ++y) {
		imgSize += convertLine(imgBuf+imgSize, img, y, isRLC, isAlpha);
	}
	return imgSize;
}
typedef struct {
    int             len;
	int 			width;
	int 			height;
	bool			isAlpha;
	bool			isExtFlash;
	bool			isRLC;
	int 			size;
	int 			gain;
} imgInfoStruct;
bool getImgInfo(char* imgBuf, QString fname, imgInfoStruct* imgInfo, float ratioZip){
    bool isRLC = getZipType(fname);
    bool isAlpha = getAlphaType(fname);
	QImage* img = loadImg(fname);
	if((img->height() > MAX_LCD_HEIGHT) || (img->width() > MAX_LCD_HEIGHT)){
        return false;
	}
	int size = convertImage(imgBuf, img, isRLC, isAlpha);
    unsigned int unZipSize = getColorSize(isAlpha)*img->width()*img->height();
    float gain = (float)size / (float)unZipSize;
    if(gain > ratioZip){
        isAlpha = false;
        size = convertImage(imgBuf, img, isRLC, isAlpha);
	}
	imgInfo->width = img->width();
	imgInfo->height = img->height();
	imgInfo->isRLC = isRLC;
	imgInfo->isAlpha = isAlpha;
	imgInfo->size = size;
	imgInfo->gain = gain;
	return true;
}

char*common_head = (char*) "\
/*************************************************************\n\
** this file is all picture data source file\n\
** by ZXHD\n\
*************************************************************/\n\
\n\
";
char*font_h_head = (char*) "\
#ifndef _FONT_H\n\
#define _FONT_H\n\
\n\
";
char*font_h_tail = (char*) "\
\n\
#endif\t//_FONT_H\n\
";
char*data_h_head = (char*) "\
#ifndef _PICTURE_DATA_H\n\
#define _PICTURE_DATA_H\n\
\n\
";
char*data_h_tail = (char*) "\
\n\
#endif// _PICTURE_DATA_H\n\
";
char*c_head = (char*) "\
#include \"picture.h\n\
#include \"picture_data.h\n\
";
char*h_head = (char*) "\
#ifndef _PICTURE_H\n\
#define _PICTURE_H\n\
\n\
";
char*info_struct = (char*) "\
\n\
typedef struct{\n\
    const unsigned char *addr;\n\
    const unsigned short width;\n\
    const unsigned short height;\n\
    const unsigned char alpha;			//0: no alpha, 1: has alpha, 2: no alpha, RLC, 3: has alpha, RLC\n\
   const unsigned char external_flag;	//0: mcu flash, 1: external spi flash or emmc.\n\
}picture_info_struct;\n\
\n\
";
char*h_tail = (char*) "\
\n\
#endif  // _PICTURE_H\n\
";

void openFile(const char*name, QFile&file)
{
	file.setFileName(name);
	file.open(QIODevice::ReadWrite);
	file.resize(0);
}
void openFile(QString name, QFile&file)
{
	file.setFileName(name);
	file.open(QIODevice::ReadWrite);
	file.resize(0);
}
void saveFile(const char*name, QByteArray data)
{
	QFile file;

	openFile(name, file);
	file.write(data);
	file.close();
}
void appendText(char*txt, QByteArray&data)
{
	data.insert(data.size(), txt, strlen(txt));
}
void prependText(char*txt, QByteArray&data)
{
	data.insert(0, txt, strlen(txt));
}
/**
  * @brief	:crc16 calculation function
  * @param	:crc16 --> the first crc16 value,it can fill 0 at first use
  *			:buf --> the calculate data point
  *			:len --> the calculate data length
  * @retval :return the crc16 value
  * @author :ZXHD
  */
unsigned short calculate_crc16(unsigned short crc16, char*buf, unsigned int len)
{
	unsigned short msb;
	unsigned short data;
	unsigned short gx = 0x8005;
	unsigned int i = 0, j = 0;

	if (len==0) {
		return 0;
	}
	if (NULL==buf) {
		qDebug("%s,the data is NULL\r\n", __FUNCTION__);
		return 0;
	}
	for (i = 0; i<len; ++i) {
		data = (unsigned short)
		buf[i];
		data = data << 8;
		crc16 = crc16^data;
		j	= 0;
		do {
			msb = crc16&0x8000;
			crc16 = crc16 << 1;
			if (msb==0x8000) {
				crc16 = crc16^gx;
			}
			j++;
		}
		while(j<8);
	}
	return crc16;
}
bool scanData(const QDir&fromDir, const QStringList&filters, QStringList&toFnameLst, QStringList&toPathLst)
{
	toFnameLst.clear();
	toFnameLst.clear();
	QFileInfoList fileInfoList = fromDir.entryInfoList(filters, QDir::AllDirs | QDir::Files);

	foreach (QFileInfo fileInfo, fileInfoList) {
		if (fileInfo.fileName()=="."||fileInfo.fileName()=="..") {
			continue;
		}
		if (fileInfo.isDir()) {
			if (!scanData(fileInfo.filePath(), filters, toFnameLst, toPathLst)) {
				return false;
			}
		}
		else {
			toPathLst.append(fileInfo.filePath());
			toFnameLst.append("pic_"+fileInfo.baseName());
		}
	}
	return true;
}
void MainWindow::showWarning(const QString&msg)
{
	QMessageBox::warning(this, 
		tr("Warning"), 
		msg, 
		QMessageBox::Yes);
}
bool MainWindow::createDir(QString path)
{
	QDir dir;

	if (dir.exists(path)) {
#if 0
		showWarning(tr("out Path already exist"));
		return false;

#else

		//		QDir qDir(path);
		//		qDir.removeRecursively();
#endif
	}
	if (!dir.mkpath(path)) {
		showWarning(tr("out Path cannot create"));
		return false;
	}
	dir.setCurrent(path);
	return true;
}
#define FONT_FILE_NAME  "font.h"
#define PIC_FILE_NAME  "picture.h"
void MainWindow::on_pushButtonConvert_clicked()
{
	unsigned char colorOrder = ui->comboBoxRGB->currentIndex();
	unsigned char colorSize = ui->comboBox888->currentIndex();
	unsigned char byteOrder = ui->comboBoxEndian->currentIndex();
	QString version = ui->lineEditVersion->text();
	bool ok;
	int zipRadio = ui->lineEditRadioZip->text().toInt(&ok);

	if (!ok||zipRadio<0||zipRadio>100) {
		showWarning(tr("compress ratio != 0-100!"));
		return;
	}
	QString pathOut;

	pathOut = ui->lineEditDirOut->text();
	if (!createDir(pathOut)) {
		return;
	}
	char buf[100];
	QByteArray data;
	QFile file;
	unsigned int offset;

	QVector <int> fileLenLst;
    QVector <imgInfoStruct> imgInfoLst;
    QStringList toFnameLst, toPathLst;
	QString pathFont = ui->lineEditDirFont->text();
	QStringList filtersFont = {
		"*.bin"
	};
	scanData(pathFont, filtersFont, toFnameLst, toPathLst);
	data.clear();
    fileLenLst.clear();
	offset = 0;
	foreach (QString fileName, toFnameLst) {
		file.setFileName(fileName);
		if (false==file.open(QIODevice::ReadWrite)) {
			showWarning(tr("font file not exist!"));
			return;
		}
		unsigned int len = file.size();

		file.seek(0);
		data.insert(data.size(), file.readAll());
		file.close();
		fileLenLst.append(offset);
		offset += len;
	}
	offset = 16+data.size();
	if (toFnameLst.count()>0) {
		char temp[4096] = {
			0
		};
		memset(temp, 0xFF, sizeof(temp));
		unsigned int remind_size = (data.size()+16) % 4096;

        if (remind_size > 0) {
			data.insert(0, temp, 4096-remind_size);
			offset += (4096-remind_size);
		}
	}
    saveFile(FONT_FILE_NAME, data);
	data.clear();
    openFile("font.h", file);
    appendText(common_head, data);
    appendText(font_h_head, data);
	offset = 0;
	foreach (QString fileName, toFnameLst) {
		snprintf(buf, sizeof(buf), "#define\t%s_OFFSET\t\t0x%08X\r\n", 
			fileName.toUpper().toLatin1().data(), fileLenLst[offset]);
		data.append(buf);
	}
	appendText(font_h_tail, data);
	file.write(data);
	file.close();

	QString pathPic = ui->lineEditDirPic->text();
	QStringList filtersPic = {
		"*.bmp", "*.png"
	};
	scanData(pathPic, filtersPic, toFnameLst, toPathLst);
    char imgBuf[MAX_LCD_WIDTH * MAX_LCD_HEIGHT * 5];
    data.clear();
    foreach (QString fname, toFnameLst) {
        if (getFshType(fname)) {
            imgInfoStruct imgInfo;
             if(!getImgInfo(imgBuf, fname, &imgInfo, zipRadio)){
				showWarning("Big Image!");
				qApp->exit();
			}
            imgInfoLst.append(imgInfo);
            data.insert(data.size(), imgBuf, imgInfo.size);
		}
	}
    saveFile(PIC_FILE_NAME, data);
	
/*	font data
    padding
    CRC
    picture_data.size
    picture data		4K boundary start
*/
    file.setFileName(FONT_FILE_NAME);
    if (false==file.open(QIODevice::ReadWrite)) {
        showWarning(tr("font file not exist!"));
        return;
    }
    offset = file.size();
    file.seek(0);
    data.insert(0, file.readAll());

    unsigned short crc16 = calculate_crc16(0, data.data(), data.size());
    memset(buf, 0, sizeof(buf));
    buf[0] = (crc16 >> 0) & 0xFF;
    buf[1] = (crc16 >> 8) & 0xFF;
    buf[2] = (data.size() >> 0) & 0xFF;
    buf[3] = (data.size() >> 8) & 0xFF;
    buf[4] = (data.size() >> 16) & 0xFF;
    buf[5] = (data.size() >> 24) & 0xFF;
    data.insert(0, buf, 16);
    saveFile("res.bin", data);

	QMessageBox::warning(this,
		tr("success"),
        QString::number(fileNameList.count(), 10) +tr(" of picture converted!"),
		QMessageBox::Yes);
}
QString MainWindow::getDir(QString fname)
{
	if (fname.isEmpty()) {
		fname = ".//";
	}
	return QFileDialog::getExistingDirectory(this, tr("Open Directory"), 
		fname, 
		QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
}
void MainWindow::on_pushButtonDirPic_clicked()
{
	ui->lineEditDirPic->setText(getDir(ui->lineEditDirPic->text()));
}
void MainWindow::on_pushButtonDirFont_clicked()
{
	ui->lineEditDirPic->setText(getDir(ui->lineEditDirPic->text()));
}
void MainWindow::on_pushButtonDirOut_clicked()
{
	ui->lineEditDirPic->setText(getDir(ui->lineEditDirPic->text()));
}
MainWindow::MainWindow(QWidget*parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	ui->comboBoxRGB->addItem("RGB");
	ui->comboBoxRGB->addItem("BGR");
	ui->comboBox888->addItem("888");
	ui->comboBox888->addItem("565");
	ui->comboBoxEndian->addItem("little");
	ui->comboBoxEndian->addItem("big");
	ui->lineEditRadioZip->setText("100");
	QString pathCur = QDir::currentPath();

	ui->lineEditDirOut->setText(pathCur+"/out");
	ui->lineEditDirPic->setText(pathCur+"/pic");
	ui->lineEditDirFont->setText(pathCur+"/font");
}
MainWindow::~MainWindow()
{
	delete ui;
}
