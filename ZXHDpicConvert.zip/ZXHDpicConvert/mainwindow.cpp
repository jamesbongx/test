
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "stdio.h"
#include "QByteArray"
#include "QImage"
#include "QDir"
#include "QFile"
#include "QFileInfoList"
#include "QFileDialog"
#include "QMessageBox"
#include "QTextCodec"

#define MAX_LCD_WIDTH	320
#define MAX_LCD_HEIGHT	320
#define IMG_BUF_SIZE	(MAX_LCD_WIDTH * MAX_LCD_HEIGHT * 5)

int ratioZip;
QString version;

enum COLOR_CHL {	RGB, BGR	};
COLOR_CHL colorChl;
enum COLOR_FRM {	B888, B565	};
COLOR_FRM colorFrm;
enum ENDIAN {	LITTLE, BIG	};
ENDIAN endian;
bool getFshType(QString fname){
    return fname[0] == 'E';
}
bool getAlphaType(QString fname){
    return fname[1] == 'A';
}
bool getZipType(QString fname){
    return fname[2] == 'R';
}

#define FSH_BLK_SIZE	4096
char buf[FSH_BLK_SIZE];		
typedef struct {
	int width;
	int height;
	int size;
	bool isAlpha;
	bool isRLC;
	float gain;
} imgInfoStruct;
imgInfoStruct imgInfo;

QByteArray ba;
char * str2char(QString &str){
//https://blog.csdn.net/qq_46485161/article/details/116164460?spm=1001.2101.3001.6650.5&utm_medium=distribute.pc_relevant.none-task-blog-2%7Edefault%7EBlogCommendFromBaidu%7Edefault-5-116164460-blog-52465203.pc_relevant_multi_platform_whitelistv1&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2%7Edefault%7EBlogCommendFromBaidu%7Edefault-5-116164460-blog-52465203.pc_relevant_multi_platform_whitelistv1&utm_relevant_index=6
//  std::string str = str.toStdString();
    ba.clear();
    ba = str.toLocal8Bit();  //toLatin1();	toUtf8()	toAscii()
    return ba.data();
//  QString qstr2 = QString::fromLocal8Bit(c);  //fromUtf8(c);
}
char picName[80];
char* getPicName(QString fname, imgInfoStruct &info){
    snprintf(picName, sizeof(picName), "PIC_%s_%dx%d",
		str2char(fname), info.width, info.height);
    return picName;
}

void saveFile(const char * name, QByteArray data){
	QFile file;
	file.setFileName(name);
	file.open(QIODevice::ReadWrite);
	file.resize(0);
	file.write(data);
	file.close();
}

char * font_h_head = (char *) "\
#ifndef _FONT_H\n\
#define _FONT_H\n\
\n\
//CRC		2 bytes\n\
//data.size	4 bytes\n\
//reserved	10bytes\n\
//font data	padding to 4K boundary from start of file\n\
//picture data\n\
\n\
";
char * font_h_tail = (char *) "\
\n\
#endif\t//_FONT_H\n\
";

char * picExt_h_head = (char *) "\
#ifndef _PICEXT_H\n\
#define _PICEXT_H\n\
\n\
";
char * picExt_h_tail = (char *) "\
\n\
#endif\t//_PICEXT_H\n\
";
char * picInt_h_head = (char *) "\
#ifndef _PICINT_H\n\
#define _PICINT_H\n\
\n\
";
char * picInt_h_tail = (char *) "\
\n\
#endif\t//_PICINT_H\n\
";

char * picInfoExt_h_head = (char *) "\
#ifndef _PICINFOINT_H\n\
#define _PICINFOINT_H\n\
\n\
";
char * picInfoExt_h_tail = (char *) "\
\n\
#endif\t//_PICINFOEXT_H\n\
";
char * picInfoInt_h_head = (char *) "\
#ifndef _PICINFOINT_H\n\
#define _PICINFOINT_H\n\
\n\
";
char * picInfoInt_h_tail = (char *) "\
\n\
#endif\t//_PICINFOEXT_H\n\
";

char * picInfo_head = (char *) "\
typedef struct{\n\
	const unsigned char *addr;\n\
	const unsigned short width;\n\
	const unsigned short height;\n\
	const unsigned int size;\n\
	const unsigned char flag;	//bit2=1->external flash\n\
								//bit1=1=>RLC\n\
								//bit0=1=>alpha\n\
}pic_info_struct;\n\
\n\
";
char * picInfo = (char *) "\
const pic_info_struct picInfo_%s = {\n\
    .addr	= (const unsigned char *)%s,\n\
    .width	= %d,\n\
    .height	= %d,\n\
    .size	= %d,\n\
	.flag	= 0x%.2x,\n\
};\n\
";
void addImgInfo(QByteArray &data, QString &fname, imgInfoStruct &info, int offset){
	unsigned char flag = 0;
	if(getAlphaType(fname)) {
		flag |= 1;
	}
	if(getZipType(fname)) {
		flag |= 2;
		float tmp = info.gain * 100.0;
		snprintf(picName, sizeof(picName), "//compress ratio = %f%%\n", tmp);
		data.append(picName);
	}
	char *name;
	if(getFshType(fname)) {
		flag |= 4;
		snprintf(picName, sizeof(picName), "0x%08x", offset);
		name = picName;
	}else {
		name = getPicName(fname, info);
	}
    snprintf(buf, sizeof(buf), picInfo
    , str2char(fname)
    , name
    , info.width, info.height, info.size
    , flag);
	data.append(buf);
}

char * common_head = (char *) "\
/*************************************************************\n\
** Picture Resources Converter\n\
**		by ZXHD\n\
** Version : %s\n\
** Color Channel   = %s\n\
** Color Format    = %s\n\
** Endian          = %s\n\
** Max Compression = %d%%\n\
*************************************************************/\n\
\n\
";
void resetData(QByteArray &data){
	data.clear();
	char* chl;
	switch(colorChl){
	case RGB:
        chl = (char *)"RGB";
		break;
	case BGR:
        chl = (char *)"RGB";
		break;
	}
	char* frm;
	switch(colorFrm){
	case B888:
        frm = (char *)"888";
		break;
	case B565:
        frm = (char *)"565";
		break;
	}
    char* border;
	switch(endian){
    case LITTLE:
        border = (char *)"LITTLE";
		break;
    case BIG:
        border = (char *)"BIG";
		break;
    }
    snprintf(buf, sizeof(buf), common_head,
        str2char(version), chl, frm, border, ratioZip);
	data.append(buf);
}
char * picInt_c_head = (char *) "\
#include \"picInt.h\n\
\n\
//Picture:\n\
//	unsigned int rowOffset[height];\n\
//	RLC *pixel;\n\
//RLC:\n\
//	unsigned char length;\n\
//	Pixel pixel;\n\
//Pixel:\n\
//	unsigned char alpha		(optional)\n\
//	Color color\n\
//Color:\n\
//	565 = ((R >> 3) << 11) + ((G >> 2) << 5) + ((B >> 3) << 0);\n\
\n\
";

int getColorSize(){
	int len = 2;
	if(colorFrm == B888) {
		len++;
	}
	if(imgInfo.isAlpha) {
		len++;
	}
	return len;
}
unsigned int imgBufPtr;
void saveColor(char * lineBuf, unsigned char alpha, unsigned char R, unsigned char G, unsigned char B, unsigned int color){
	if(imgInfo.isAlpha) {
		lineBuf[imgBufPtr++] = alpha;
	}
	if(colorFrm == B888) {
		lineBuf[imgBufPtr++] = R;
		lineBuf[imgBufPtr++] = G;
		lineBuf[imgBufPtr++] = B;
	}else{
		if(endian == LITTLE){
			lineBuf[imgBufPtr++] = (color >> 0) & 0xFF;
			lineBuf[imgBufPtr++] = (color >> 8) & 0xFF;
		}else{
			lineBuf[imgBufPtr++] = (color >> 8) & 0xFF;
			lineBuf[imgBufPtr++] = (color >> 0) & 0xFF;
		}
	}
}
void convertLine(char * lineBuf, QImage * img, unsigned int y){
	unsigned char color, alpha, R, G, B;
	unsigned int oldColor, len;

	imgBufPtr = 0;
	const uchar * it = img->constScanLine(y);
	int width = img->width();

	for(int x = 0; x < width; ++x) {
        B	= * (it++);
		G	= * (it++);
        R	= * (it++);
		if(colorChl == BGR) {
			R	^= B;
			B	^= R;
			R	^= B;
		}
		alpha = * (it++);
		color = ((R >> 3) << 11) + ((G >> 2) << 5) + ((B >> 3) << 0);
		if(imgInfo.isRLC) {
			if(colorFrm == B888) {
				color = (R << 16) + (G << 8) + (B << 0);
			}
			if(imgInfo.isAlpha) {
				color += (alpha << 24);
			}
			if(x == 0) {
				len = 0;
				oldColor = color;
				continue;
			}else if(x < width - 1) {
                if((color == oldColor) && (len < 255)) {
                    len++;
					continue;
                }
            }
			lineBuf[imgBufPtr++] = len;
			len = 0;
			oldColor = color;
		}
		saveColor(lineBuf, alpha, R, G, B, color);
	}
}
void convertImage(char * imgBuf, QImage * img){
	unsigned int imgSize = 0;
	if(imgInfo.isRLC) {
		imgSize = 4 * img->height();
	}
    int ptr = 0;
	for(int y = 0; y < img->height(); ++y) {
        if((imgSize + (img->width() * 5)) > IMG_BUF_SIZE){
            imgSize = -1;
            break;
		}
		convertLine(imgBuf + imgSize, img, y);
		if(imgInfo.isRLC) {
			if(endian == LITTLE){
                imgBuf[ptr++] = (imgSize >> 0) & 0xFF;
                imgBuf[ptr++] = (imgSize >> 8) & 0xFF;
                imgBuf[ptr++] = (imgSize >> 16)& 0xFF;
                imgBuf[ptr++] = (imgSize >> 24)& 0xFF;
			}else{
                imgBuf[ptr++] = (imgSize >> 24)& 0xFF;
                imgBuf[ptr++] = (imgSize >> 16)& 0xFF;
                imgBuf[ptr++] = (imgSize >> 8) & 0xFF;
                imgBuf[ptr++] = (imgSize >> 0) & 0xFF;
			}
		}
		imgSize += imgBufPtr;
/*		if(imgSize > 0xFFFF){
			return -1;
		}*/
	}
	imgInfo.size = imgSize;
}
void MainWindow::showWarning(const QString & msg){
	QMessageBox::warning(this, 
		tr("Warning"), 
		msg, 
		QMessageBox::Yes);
}
bool MainWindow::getImgInfo(char * imgBuf, QString fname, QString path){
	imgInfo.isRLC = getZipType(fname);
	imgInfo.isAlpha = getAlphaType(fname);
	QImage img;
	img.load(path);
	imgInfo.width = img.width();
	imgInfo.height = img.height();
	if((imgInfo.width == 0) || (imgInfo.height == 0)){
		snprintf(imgBuf, 100, "%s invalid format", 
		str2char(fname));
		showWarning(imgBuf);
//		qApp->exit();
		return false;
	}
	unsigned int unZipSize = getColorSize() * img.width() * img.height();
	if(unZipSize > IMG_BUF_SIZE) {
		snprintf(imgBuf, 100, "%s too big (%d > %d)", 
		str2char(fname), unZipSize, IMG_BUF_SIZE);
		showWarning(imgBuf);
//		qApp->exit();
		return false;
	}
	convertImage(imgBuf, &img);
	if(imgInfo.size < 0){
		snprintf(imgBuf, 100, "%s too big for RLC", 
		str2char(fname));
		showWarning(imgBuf);
//		qApp->exit();
		return false;
	}
	if(imgInfo.isRLC) {
		imgInfo.gain = (float)imgInfo.size / (float)unZipSize;
		float maxRatio = (float)ratioZip / 100.0;
		if(imgInfo.gain > maxRatio) {
			imgInfo.isRLC = false;
			convertImage(imgBuf, &img);
		}
	}
	return true;
}

/**
*@brief	:crc16 calculation function
*@param	:crc16 --> the first crc16 value,it can fill 0 at first use
*		:buf --> the calculate data point
*		:len --> the calculate data length
*@retval :return the crc16 value
*/
unsigned short calculate_crc16(unsigned short crc16, char * buf, unsigned int len)
{
	unsigned short msb;
	unsigned short data;
	unsigned short gx = 0x8005;
	unsigned int i = 0, j = 0;

	if(len == 0) {
		return 0;
	}
	if(NULL == buf) {
		qDebug("%s,the data is NULL\r\n", __FUNCTION__);
		return 0;
	}
	for(i = 0; i < len; ++i) {
		data = (unsigned short)
		buf[i];
		data = data << 8;
		crc16 = crc16 ^ data;
		j	= 0;
		do {
			msb = crc16 & 0x8000;
			crc16 = crc16 << 1;
			if(msb == 0x8000) {
				crc16 = crc16 ^ gx;
			}
			j++;
		}
		while(j < 8);
	}
	return crc16;
}
bool scanData(const QDir & fromDir, const QStringList & filters, QStringList & toFnameLst, QStringList & toPathLst)
{
	toFnameLst.clear();
	toFnameLst.clear();
	QFileInfoList fileInfoList = fromDir.entryInfoList(filters, QDir::AllDirs | QDir::Files);

	foreach(QFileInfo fileInfo, fileInfoList) {
		if(fileInfo.fileName() == "." || fileInfo.fileName() == "..") {
			continue;
		}
		if(fileInfo.isDir()) {
			if(!scanData(fileInfo.filePath(), filters, toFnameLst, toPathLst)) {
				return false;
			}
		}else {
			toPathLst.append(fileInfo.filePath());
            toFnameLst.append(fileInfo.baseName());
		}
	}
	return true;
}
bool MainWindow::createDir(QString path){
	QDir dir;

	if(dir.exists(path)) {
#if 0
		showWarning(tr("out Path already exist"));
		return false;
#else
//		QDir qDir(path);
//		qDir.removeRecursively();
#endif
	}
	if(!dir.mkpath(path)) {
		showWarning(tr("out Path cannot create"));
		return false;
	}
	dir.setCurrent(path);
	return true;
}
#define FONT_FILE_NAME "font.bin"
#define PIC_FILE_NAME "picture.bin"
void MainWindow::on_pushButtonConvert_clicked()
{
    colorChl = (COLOR_CHL)ui->comboBoxRGB->currentIndex();
    colorFrm = (COLOR_FRM)ui->comboBox888->currentIndex();
    endian = (ENDIAN)ui->comboBoxEndian->currentIndex();
	version = ui->lineEditVersion->text();
    bool ok;
	ratioZip = ui->lineEditRadioZip->text().toInt(&ok);
	if(!ok || ratioZip < 0 || ratioZip > 100) {
		showWarning(tr("compress ratio != 0-100!"));
		return;
	}
	QString pathOut = ui->lineEditDirOut->text();
	QString pathFont = ui->lineEditDirFont->text();
	QString pathPic = ui->lineEditDirPic->text();
	

	if(!createDir(pathOut)) {
		return;
	}
	QByteArray data;
	QFile file;
    unsigned int offset, inx;

	QVector < int > fileLenLst;
	QVector < imgInfoStruct > imgInfoLst;
	QStringList toFnameLst, toPathLst;
////////////////////////////////////////////////////////	
	QStringList filtersFont = {
		"*.bin"
	};
	scanData(pathFont, filtersFont, toFnameLst, toPathLst);
	
	data.clear();
	fileLenLst.clear();
	offset = 0;
	foreach(QString path, toPathLst) {
		file.setFileName(path);
		if(false == file.open(QIODevice::ReadWrite)) {
			showWarning(tr("font file not exist!"));
			return;
		}
		unsigned int len = file.size();

		file.seek(0);
		data.insert(data.size(), file.readAll());
		file.close();
		fileLenLst.append(offset);
		offset += len;
	}
	offset = 16 + data.size();
	memset(buf, 0xFF, sizeof(buf));
    unsigned int remind_size = offset % FSH_BLK_SIZE;

	if(remind_size > 0) {
		data.insert(0, buf, FSH_BLK_SIZE - remind_size);
		offset += (FSH_BLK_SIZE - remind_size);
	}
	saveFile(FONT_FILE_NAME, data);
	unsigned int picOffset = offset;
	
	resetData(data);
	data.append(font_h_head);
	inx = 0;
	foreach(QString fname, toFnameLst) {
		snprintf(buf, sizeof(buf), "#define FONT_%s\t\t0x%08X\r\n", 
			str2char(fname), fileLenLst[inx]);
		data.append(buf);
		inx++;
	}
	data.append(font_h_tail);
	saveFile("font.h", data);
////////////////////////////////////////////////////////	
	QStringList filtersPic = {
		"*.bmp", "*.png"
	};
	scanData(pathPic, filtersPic, toFnameLst, toPathLst);
	char imgBuf[IMG_BUF_SIZE];
	QStringList toFnameLstExt, toPathLstExt;
	QStringList toFnameLstInt, toPathLstInt;
	inx = 0;
	foreach(QString fname, toFnameLst) {
		if(getFshType(fname)) {
			toFnameLstExt.append(fname);
            toPathLstExt.append(toPathLst[inx]);
		}else{
            toFnameLstInt.append(fname);
            toPathLstInt.append(toPathLst[inx]);
		}
		inx++;
	}
	
	data.clear();
	fileLenLst.clear();
	offset = picOffset;
	inx = 0;
	foreach(QString fname, toFnameLstExt) {
		if(!getImgInfo(imgBuf, fname, toPathLstExt[inx])){
			return;
		}
		data.insert(data.size(), imgBuf, imgInfo.size);

		imgInfoLst.append(imgInfo);
		fileLenLst.append(offset);
		offset += imgInfo.size;
		inx++;
	}
	saveFile(PIC_FILE_NAME, data);
	
	resetData(data);
	data.append(picExt_h_head);
	snprintf(buf, sizeof(buf), "#define PICTURE_OFFSET\t\t0x%08X\n\n", picOffset);
	data.append(buf);
    inx = 0;
    foreach(QString fname, toFnameLstExt) {
        snprintf(buf, sizeof(buf), "#define %s\t\t0x%08X\t\n",
            getPicName(fname, imgInfoLst[inx]),
            fileLenLst[inx]);
        data.append(buf);
        inx++;
	}
	data.append(picExt_h_tail);
	saveFile("picExt.h", data);

	resetData(data);
	data.append(picInfoExt_h_head);
	inx = 0;
	foreach(QString fname, toFnameLstExt) {
        addImgInfo(data, fname, imgInfoLst[inx], fileLenLst[inx]);
        inx++;
	}
	data.append(picInfoExt_h_tail);
	saveFile("picInfoExt.h", data);
////////////////////////////////////////////////////////		
/*	CRC			2 bytes
	data.size	4 bytes
	reserved	10bytes
	font data	padding to 4K boundary from start of file
	picture data
*/
	file.setFileName(FONT_FILE_NAME);
	if(false == file.open(QIODevice::ReadWrite)) {
		showWarning(tr("font file not exist!"));
		return;
	}
	offset = file.size();
	file.seek(0);
	data.insert(0, file.readAll());
	unsigned short crc16 = calculate_crc16(0, data.data(), data.size());

	memset(buf, 0, sizeof(buf));
	buf[0] = (crc16 >> 0) & 0xFF;
	buf[1] = (crc16 >> 8) & 0xFF;
	buf[2] = (data.size() >> 0) & 0xFF;
	buf[3] = (data.size() >> 8) & 0xFF;
	buf[4] = (data.size() >> 16) & 0xFF;
	buf[5] = (data.size() >> 24) & 0xFF;
	data.insert(0, buf, 16);
	saveFile("res.bin", data);
////////////////////////////////////////////////////////	
	resetData(data);
	data.append(picInt_c_head);
	fileLenLst.clear();
	offset = 0;
	inx = 0;
	foreach(QString fname, toFnameLstInt) {
		if(!getImgInfo(imgBuf, fname, toPathLstInt[inx])){
			return;
		}
		snprintf(buf, sizeof(buf), "const unsigned char %s[%d] = {\t", 
            getPicName(fname, imgInfo),
			imgInfo.size);
		data.append(buf);
		for(int i = 0; i < imgInfo.size; i++) {
			if((i++ % 16) == 0) {
				data.append((char *) "\n\t");
			}
			snprintf(buf, sizeof(buf), "0x%02X, ", imgBuf[i] &0xFF);
			data.append(buf);
		}
		data.append((char *) "\n};\n\n");
			
		imgInfoLst.append(imgInfo);
		fileLenLst.append(offset);
		offset += imgInfo.size;
		inx++;
	}
	saveFile("picInt.c", data);
	
	resetData(data);
	data.append(picInt_h_head);
    inx = 0;
    foreach(QString fname, toFnameLstInt) {
        snprintf(buf, sizeof(buf), "extern const unsigned char %s[%d];\n",
            getPicName(fname, imgInfoLst[inx]),
            imgInfoLst[inx].size);
        data.append(buf);
        inx++;
	}
	data.append(picInt_h_tail);
	saveFile("picInt.h", data);
	
	resetData(data);
	data.append(picInfoInt_h_head);
	inx = 0;
	foreach(QString fname, toFnameLstInt) {
        addImgInfo(data, fname, imgInfoLst[inx], fileLenLst[inx]);
        inx++;
	}
	data.append(picInfoInt_h_tail);
	saveFile("picInfoInt.h", data);
	
	QMessageBox::warning(this, 
		tr("success"), 
        QString::number(toFnameLst.count(), 10)+tr(" picture converted!"),
		QMessageBox::Yes);
}
QString MainWindow::getDir(QString fname)
{
	if(fname.isEmpty()) {
		fname = ".//";
	}
	return QFileDialog::getExistingDirectory(this, tr("Open Directory"), 
		fname, 
		QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
}
void MainWindow::on_pushButtonDirPic_clicked()
{
	ui->lineEditDirPic->setText(getDir(ui->lineEditDirPic->text()));
}
void MainWindow::on_pushButtonDirFont_clicked()
{
	ui->lineEditDirPic->setText(getDir(ui->lineEditDirPic->text()));
}
void MainWindow::on_pushButtonDirOut_clicked()
{
	ui->lineEditDirPic->setText(getDir(ui->lineEditDirPic->text()));
}
MainWindow::MainWindow(QWidget * parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	ui->comboBoxRGB->addItem("RGB");
	ui->comboBoxRGB->addItem("BGR");
	ui->comboBox888->addItem("888");
	ui->comboBox888->addItem("565");
	ui->comboBoxEndian->addItem("little");
	ui->comboBoxEndian->addItem("big");
	ui->lineEditRadioZip->setText("100");
	QString pathCur = QDir::currentPath();

	ui->lineEditDirOut->setText(pathCur + "/out");
	ui->lineEditDirPic->setText(pathCur + "/pic");
	ui->lineEditDirFont->setText(pathCur + "/font");
}
MainWindow::~MainWindow()
{
	delete ui;
}
