#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QDir"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

typedef enum
{
    TABLE_COLUMN_ALPHA = 0,
    TABLE_COLUMN_FLASH,
    TABLE_COLUMN_FILE,

    TABLE_COLUMN_SUM
}TABLE_COLUMN_TYPE;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    bool scanData(const QDir &fromDir, const QStringList &filters);
    bool scanData_bin(const QDir &fromDir, const QStringList &filters);
    
public:
    QStringList filePathList;
    QStringList fileNameList;
    QStringList fileCompleteSuffixNameList;

    QStringList filePathList_bin;
    QStringList fileNameList_bin;
    QStringList fileCompleteSuffixNameList_bin;
    QStringList fileLenList_bin;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_refresh_clicked();

    void on_pushButton_dir_clicked();

    void on_checkBox_flash_clicked();

    void on_checkBox_alpha_clicked();

    void on_tableWidget_cellClicked(int row, int column);

    void on_pushButton_bin_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
