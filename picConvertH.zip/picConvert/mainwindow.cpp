
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QFile"
#include "stdio.h"
#include "QByteArray"
#include "QImage"
#include "QDir"
#include "QFileInfoList"
#include "QFileDialog"
#include "QMessageBox"
#include "QTextCodec"

char* getFileName(QStringList lst, int inx){
    return lst.at(inx).toLocal8Bit().data();
}
bool sExtFlash(QString fname){
    return fname[0] == 'E';
}
bool isAlpha(void){
    return fname[1] == 'A';
}
bool isRLC(void){
    return fname[2] == 'R';
}
unsigned char colorFrm = 0;		//888,565
unsigned char colorChl = 0;		//RGB,BGR
unsigned int bufPtr;
int getColorSize(bool isAlpha){
	int len = 2;
	if (colorFrm == 0) {
		len++;
	}
	if (isAlpha) {
		len++;
	}
	return len;
}
int getZipGain(QImage* img, unsigned int len){
	return getColorSize(isAlpha) * img->width() * img->height() - len;
}
void saveColor(char ^lineBuf, unsigned char alpha, unsigned char R, unsigned char G, unsigned char B, unsigned int color, bool isAlpha){
	if (isAlpha) {
		lineBuf[bufPtr++] = alpha;
	}
	if (colorFrm == 0) {
		lineBuf[bufPtr++] = R;
		lineBuf[bufPtr++] = G;
		lineBuf[bufPtr++] = B;
	}else {
		lineBuf[bufPtr++] = (color >> 8) & 0xFF;
		lineBuf[bufPtr++] = (color >> 0) & 0xFF;
	}
}
unsigned int convertLine(char ^lineBuf, QImage* img, unsigned int y, bool isRLC, bool isAlpha){
	unsigned char alpha, R, G, B;
	unsigned int color, oldColor, len;
	bufPtr = 0;
Retry:
	const uchar* it = img->constScanLine(y);
	int width = img->width();
	for (int x = 0; x < width; ++x) {
		R = *(it++);
		G = *(it++);
		B = *(it++);
		if(colorChl == 1){
			R ^= B;
			B ^= R;
			R ^= B;
		}
		alpha = *(it++);
		color = ((R >> 3) << 11) + ((G >> 2) << 5) + ((B >> 3) << 0);
		if (isRLC) {
			if (colorFrm == 1) {
				color = (R << 16) + (G << 8) + (B << 0);
			}
			if (isAlpha) {
				color += (alpha << 24);
			}
			if (x == 0){
				oldColor = color;
				len = 1;
				continue;
			}else if ((color == oldColor) && (len < 256)){
				len++;
				continue;
			}else{
				lineBuf[bufPtr++] = len;
				len = 1;
				oldColor = color;
			}
		}
		saveColor(lineBuf, alpha, R, G, B, color, isAlpha);
	}
	if (isRLC) {
		lineBuf[bufPtr++] = i;
		saveColor(lineBuf, alpha, R, G, B, color, isAlpha);
		if(getZipGain(img, len) < 0){
			isRLC = false;
			bufPtr = 0;
			lineBuf[bufPtr++] = 0;
			goto Retry;
		}
	}
	return bufPtr;
}
QImage* loadImg(QString fname){
    QImage* img = new QImage();
    img->load(fname);
    return img;
}
#define MAX_LCD_WIDTH	320
#define MAX_LCD_HEIGHT	320
int convertImage(char* imgBuf, QImage* img, bool isRLC, bool isAlpha){
	char lineBuf[MAX_LCD_WIDTH * 5];
	
	QByteArray image_data;
	image_data.clear();
	unsigned int imgSize = 0;
	for (int y = 0; y < img->height(); ++y) {
		unsigned int lineLen = convertLine(lineBuf, img, y, isRLC, isAlpha);
		memmove(image_data + imgSize, lineBuf, lineLen);
		imgSize += lineLen;
	}
	return imgSize;
}
typedef{
	int width;
	int height;
	bool isAlpha;
	bool isExtFlash;
	bool isRLC;
	int size;
	int gain;
}imgInfoStruct;
bool getImgInfo(char* imgBuf, QString fname, imgInfoStruct* imgInfo){
	isRLC = isRLC(fname);
	isAlpha = isAlpha(fname);
	QImage* img = loadImg(fname);
	if((img->height() > MAX_LCD_HEIGHT) || (img->width() > MAX_LCD_HEIGHT)){
		return false
	}
	int size = convertImage(imgBuf, img, isRLC, isAlpha);
	int gain = getZipGain(img, size);
	if(gain < 0){
		isAlpha = false
		int size = convertImage(imgBuf, img, isRLC, isAlpha);
	}
	imgInfo->width = img->width();
	imgInfo->height = img->height();
	imgInfo->isRLC = isRLC;
	imgInfo->isAlpha = isAlpha;
	imgInfo->size = size;
	imgInfo->gain = gain;
	return true;
}
QFile picture_file;
QByteArray picture_data;
void openFile(const char *name){
    picture_file.setFileName(name);
    picture_file.open(QIODevice::ReadWrite);
    picture_file.resize(0);
    picture_data.resize(0);
}
void saveFile(const char *name){
    picture_file.setFileName(name);
    picture_file.open(QIODevice::ReadWrite);
    picture_file.resize(0);
    picture_file.write(picture_data);
    picture_file.close();
}

const char *data_head =
"/*************************************************************\n\r"
"** this file is all picture data source file\n\r"
"** by ZXHD\n\r"
"*************************************************************/\n\r"
"\n\r"
;
const char *data_h_head =
"#ifndef _PICTURE_DATA_H\n\r"
"#define _PICTURE_DATA_H\n\r"
"\n\r"
;
const char *data_h_tail =
"\n\r"
"#endif// _PICTURE_DATA_H\n\r"
;
const char *c_head =
"#include \"picture.h\n\r"
"#include \"picture_data.h\n\r"
;
const char *h_head =
"#ifndef _PICTURE_H\n\r"
"#define _PICTURE_H\n\r"
"\n\r"
;
const char *info_struct =
"\n\r"
"typedef struct{\n\r"
"	const unsigned char *addr;\n\r"
"	const unsigned short width;\n\r"
"	const unsigned short height;\n\r"
"	const unsigned char alpha;			//0: no alpha, 1: has alpha, 2: no alpha, RLC, 3: has alpha, RLC\n\r"
"   const unsigned char external_flag;	//0: mcu flash, 1: external spi flash or emmc.\n\r"
"}picture_info_struct;\n\r"
"\n\r"
;
const char *h_tail =
"\n\r"
"#endif// _PICTURE_H\n\r"
;
void appendText(char *txt){
    picture_data.insert(picture_data.size(), txt, strlen(txt));
}
void prependText(char *txt){
    picture_data.insert(0, txt, strlen(txt));
}

void MainWindow::showWarning(const QString &msg){
    QMessageBox::warning(this,
        tr("Warning"),
        msg,
        QMessageBox::Yes);
}
//@brief	:crc16 calculation function
//@param	:crc16 --> the first crc16 value,it can fill 0 at first use
//		:buf --> the calculate data point
//		:len --> the calculate data length
//@retval :return the crc16 value
//@author :ZXHD
unsigned short calculate_crc16(unsigned short crc16, char * buf, unsigned int len){
	unsigned short msb;
	unsigned short data;
	unsigned short gx = 0x8005;
	unsigned int i = 0, j = 0;
	
	if (len == 0) {
		return 0;
	}
	if (NULL == buf) {
		qDebug("%s,the data is NULL\r\n", __FUNCTION__);
		return 0;
	}
	for (i = 0; i < len; ++i) {
		data = (unsigned short)
		buf[i];
		data = data << 8;
		crc16 = crc16 ^ data;
		j	= 0;
		do {
			msb = crc16 & 0x8000;
			crc16 = crc16 << 1;
			if (msb == 0x8000) {
				crc16 = crc16 ^ gx;
			}
			j++;
		}while(j < 8);
	}
	return crc16;
}



void MainWindow::on_pushButton_clicked(){
	char buf[100];
	char imgBuf[MAX_LCD_WIDTH * MAX_LCD_HEIGHT * 5];
	imgInfoStruct imgInfo[];
	int fileCnt;
	//====================== picture.bin file create ==============
	picture_data.resize(0);
	fileCnt = 0;
	foreach (QString fname, fileNameList) {
		if (isExtFlash()) {
			if(!getImgInfo(imgBuf, fname, &imgInfo[fileCnt])){
				showWarning("Big Image!");
				qApp->exit();
			}
			picture_data.insert(picture_data.size(), imgBuf, imgInfo[fileCnt].size);
			fileCnt++;
		}
	}
	saveFile("picture.bin");
	
/*	font data
    padding
    CRC
    picture_data.size
    picture data		4K boundary start
*/
    QByteArray font_data;
    QStringList fileLenList_bin;
    font_data.clear();
    fileLenList_bin.clear();
    unsigned int pic_offset = 0;
    QFile font_file;
    foreach (QString fileInfo, fileNameList_bin) {
        unsigned font_file_len = 0;
        QString fileName = filePathList_bin.at(i);

        font_file.setFileName(fileName);
        if (false == font_file.open(QIODevice::ReadWrite)) {
            showWarning(tr("font file not exist!"));
            return;
        }
        font_file_len = font_file.size();
        font_file.seek(0);
        font_data.insert(font_data.size(), font_file.readAll());
        font_file.close();

        snprintf(buf, sizeof(buf), "#define\t%s_OFFSET\t\t0x%08X\r\n",
            fileNameList_bin.at(i).toUpper().toLatin1().data(), pic_offset);
        fileLenList_bin.append(buf);
        pic_offset += font_file_len;
    }
    if (ui->tableWidget_bin->rowCount() > 0) {
        //pad to 4K
        char temp[4096] = {
            0
        };
        memset(temp, 0xFF, sizeof(temp));
        unsigned int remind_size = (font_data.size() + 16) % 4096;

        if (remind_size > 0) {
            picture_data.insert(0, temp, 4096 - remind_size);
            pic_offset = (font_data.size() + 16) + (4096 - remind_size);
        }
        else {
            pic_offset = (font_data.size() + 16);
        }
        picture_data.insert(0, font_data);
    }
    else {
        pic_offset = 16;
    }
    unsigned short crc16 = calculate_crc16(0, picture_data.data(), picture_data.size());
    memset(buf, 0, sizeof(buf));
    buf[0] = (crc16 >> 0) & 0xFF;
    buf[1] = (crc16 >> 8) & 0xFF;

    buf[2] = (picture_data.size() >> 0) & 0xFF;
    buf[3] = (picture_data.size() >> 8) & 0xFF;
    buf[4] = (picture_data.size() >> 16) & 0xFF;
    buf[5] = (picture_data.size() >> 24) & 0xFF;
    picture_data.insert(0, buf, 16);

    saveFile("picture_font_merge.bin");



    openFile("picture_data.c");
    appendText((char*)data_head);
	picture_data.resize(0);
	fileCnt = 0;
	foreach (QString fname, fileNameList) {
		if (!isExtFlash()) {
			if(!getImgInfo(imgBuf, fname, &imgInfo[fileCnt])){
				showWarning("Big Image!");
				qApp->exit();
			}
			picture_data.insert(picture_data.size(), imgBuf, imgInfo[fileCnt].size);
			for(int i = 0; i < imgInfo[fileCnt].size; i++){
				if ((fileLen++ % 16) == 0){
					appendText((char*)"\r\n\t");
				}
				snprintf(buf, sizeof(buf), "0x%02X, ", imgBuf[i] & 0xFF);
				picture_data.insert(picture_data.size(), buf);
			}
            appendText((char*)"\r\n};\r\n\r\n");
            snprintf(buf, sizeof(lineBuf), "const unsigned char %s_data_%dx%d[%d] = \r\n{",
                fname, imgInfo[fileCnt].height, imgInfo[fileCnt].width, imgInfo[fileCnt].size);
            picture_data.insert(offset, buf);
			fileCnt++;
		}
	}
	
	
    picture_file.write(picture_data);
    picture_file.close();
	//====================== picture.h file create ==============
    openFile((char*)"picture.h");
    appendText((char*)data_head);
    appendText((char*)h_head);

    snprintf(buf, sizeof(buf), "#define PIC_CRC16\t\t0x%04X\r\n", crc16 & 0xFFFF);
    picture_data.insert(picture_data.size(), buf);
    appendText((char*)"#define PIC_HEAD_SIZE\t16\r\n");
    snprintf(buf, sizeof(buf), "#define PIC_OFFSET\t\t0x%08X\r\n", pic_offset);
    picture_data.insert(picture_data.size(), buf);

    appendText((char*)"\r\n\r\n");

    for (int i = 0; i < fileLenList_bin.count(); i++) {
        picture_data.insert(picture_data.size(), fileLenList_bin.at(i));
    }
    appendText((char*)info_struct);
	
	//====================== picture_data.h file create =========
    openFile("picture_data.h");
    appendText((char*)data_head);
    appendText((char*)data_h_head);

    tablePtr	= 0;
    for (int i = 0; i < fileLenLst.size(); ++i){
        snprintf(buf, sizeof(buf), "extern const unsigned char %s_data[%d];\r\n",
            getFileName(),
            fileLenLst[i]);
        picture_data.insert(picture_data.size(), buf);
        tablePtr++;
    }
    appendText((char*)data_h_tail);
    picture_file.write(picture_data);
    picture_file.close();
    //====================== picture.c file create ==============
    openFile("picture.c");
    appendText((char*)data_head);
    appendText((char*)c_head);

    tablePtr	= 0;
    int lenLstPtr = 0;
    //copy fileInfoList to fileInfo
    foreach (QString fileInfo, fileNameList) {
        QImage * img = new QImage();
        img->load(fileInfo);

        snprintf(buf, sizeof(buf), "const picture_info_struct %s_info = {\r\n",
            getFileName());
        picture_data.insert(picture_data.size(), buf);
        if (isExtFlash()){
            snprintf(buf, sizeof(buf), "\t.addr = (const unsigned char *)0x%08x,\r\n",
				fileLenLst[lenLstPtr++]);
        }else {
            snprintf(buf, sizeof(buf), "\t.addr = (const unsigned char *)%s_data,\r\n",
                getFileName());
        }
        picture_data.insert(picture_data.size(), buf);

        snprintf(buf, sizeof(buf), "\t.width = %d,\r\n", img->width());
        picture_data.insert(picture_data.size(), buf);

        snprintf(buf, sizeof(buf), "\t.height = %d,\r\n", img->height());
        picture_data.insert(picture_data.size(), buf);

		int flg = 0;
        if (isAlpha()) {
			flg = 1;
        }
        if (isRLC()) {
			flg+= 2;
        }
		snprintf(buf, sizeof(buf), "\t.alpha = %d,\r\n", flg);
        picture_data.insert(picture_data.size(), buf);
		flg = 0;
        if (isExtFlash()){
			flg = 1;
        }
		snprintf(buf, sizeof(buf), "\t.external_flag = %d,\r\n", flg);
        picture_data.insert(picture_data.size(), buf);

        appendText((char*)"};\r\n\r\n");
        tablePtr++;
    }
    picture_file.write(picture_data);
    picture_file.close();

    //copy fileInfoList to fileInfo
    foreach (QString fileInfo, fileNameList) {
        snprintf(buf, sizeof(buf), "extern const picture_info_struct %s_info;\r\n",
            fileInfo.toLocal8Bit().data());
        picture_data.insert(picture_data.size(), buf);
    }
    appendText((char*)h_tail);
    picture_file.write(picture_data);
    picture_file.close();
    //===========================================================
    QMessageBox::warning(this,
        tr("success"),
        QString::number(fileNameList.count(), 10) +tr(" of picture converted!"),
        QMessageBox::Yes);
}
bool MainWindow::scanData(const QDir & fromDir, const QStringList & filters){
    QFileInfoList fileInfoList = fromDir.entryInfoList(filters, QDir::AllDirs | QDir::Files);

    foreach (QFileInfo fileInfo, fileInfoList) {
        if (fileInfo.fileName() == "." || fileInfo.fileName() == "..") {
            continue;
        }
        if (fileInfo.isDir()) {
            if (!scanData(fileInfo.filePath(), filters)) {
                return false;
            }
        }else {
            filePathList.append(fileInfo.filePath());
            fileNameList.append("pic_" + fileInfo.baseName());
            fileCompleteSuffixNameList.append(fileInfo.completeSuffix());
        }
    }
    return true;
}
bool MainWindow::scanData_bin(const QDir & fromDir, const QStringList & filters){
    QFileInfoList fileInfoList = fromDir.entryInfoList(filters, QDir::AllDirs | QDir::Files);
    foreach (QFileInfo fileInfo, fileInfoList) {
        if (fileInfo.fileName() == "." || fileInfo.fileName() == "..") {
            continue;
        }
        if (fileInfo.isDir()) {
            if (!scanData_bin(fileInfo.filePath(), filters)) {
                return false;
            }
        }else {
            filePathList_bin.append(fileInfo.filePath());
            fileNameList_bin.append(fileInfo.baseName());
            fileCompleteSuffixNameList_bin.append(fileInfo.completeSuffix());
        }
    }
    return true;
}
void MainWindow::on_pushButton_refresh_clicked(){
    QString dir = ui->lineEdit->text();
    QDir fromDir(dir);
    QStringList filters = {"*.bmp","*.png"};

    filePathList.clear();
    fileNameList.clear();
    fileCompleteSuffixNameList.clear();
    scanData(fromDir, filters);
    //==============================================================
    ui->tableWidget->clear();
    ui->tableWidget->setRowCount(filePathList.count());
    ui->tableWidget->setColumnCount(TABLE_COLUMN_SUM);
    QStringList header;

    header << tr("Alpha") << tr("internal F") << tr("file");
    ui->tableWidget->setHorizontalHeaderLabels(header);
    ui->tableWidget->horizontalHeader()->setStretchLastSection(true); //����?������?????
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    for (int i = 0; i < filePathList.count(); i++) {
        ui->tableWidget->setItem(i, TABLE_COLUMN_FILE, new QTableWidgetItem(filePathList.at(i)));

        if ((fileCompleteSuffixNameList.at(i).isEmpty() == false) && ((fileCompleteSuffixNameList.at(i).indexOf(".png", 0, Qt::CaseInsensitive) >
             0) || (fileCompleteSuffixNameList.at(i).indexOf(".bmp", 0, Qt::CaseInsensitive) > 0)) &&
             (fileCompleteSuffixNameList.at(i).indexOf("alpha", 0, Qt::CaseInsensitive) < 0) &&
             (fileCompleteSuffixNameList.at(i).indexOf("mcu", 0, Qt::CaseInsensitive) < 0)) {
            showWarning(tr("non-support file type") +filePathList.at(i).toLatin1().data());
            return;
        }
    }
    ui->checkBox_alpha->setChecked(false);
    ui->checkBox_flash->setChecked(false);

    dir = ui->lineEdit_bin->text();
    if (dir.isEmpty()) {
        dir = ".//font//";							//don' uised curdir as outputs are bins
    }
    //==============================================================
    QDir fromDir_bin(dir);
    QStringList filters_bin = {"*.bin"};

    filePathList_bin.clear();
    fileNameList_bin.clear();
    fileCompleteSuffixNameList_bin.clear();
    scanData_bin(fromDir_bin, filters_bin);
    //==============================================================
    ui->tableWidget_bin->clear();
    ui->tableWidget_bin->setRowCount(filePathList_bin.count());
    ui->tableWidget_bin->setColumnCount(1);
    QStringList header_bin;

    header_bin << tr("file");
    ui->tableWidget_bin->setHorizontalHeaderLabels(header_bin);
    ui->tableWidget_bin->horizontalHeader()->setStretchLastSection(true);
    ui->tableWidget_bin->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    for (int i = 0; i < filePathList_bin.count(); i++) {
        ui->tableWidget_bin->setItem(i, 0, new QTableWidgetItem(filePathList_bin.at(i)));
    }
}
QString getDir(QString file_dir){
    if (file_dir.isEmpty()) {
        file_dir = ".//";
    }
    QString dir = QFileDialog::getExistingDirectory(this, tr("Open Directory"),
        file_dir,
        QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
	return file_dir;
}
void on_pushButton_dir_clicked(){
    QString dir = getDir(ui->lineEdit->text());
    if (dir.isEmpty() == false) {
        ui->lineEdit->setText(dir);

        /* refresh the dir display. */
        on_pushButton_refresh_clicked();
    }
}
void MainWindow::on_pushButton_bin_clicked(){
    QString dir = getDir(ui->lineEdit_bin->text());
    if (dir.isEmpty() == false) {
        ui->lineEdit_bin->setText(dir);
        /* refresh the dir display. */
        on_pushButton_refresh_clicked();
    }
}
MainWindow::MainWindow(QWidget * parent): QMainWindow(parent), ui(new Ui::MainWindow){
    ui->setupUi(this);

    ui->comboBoxRGB->addItem("RGB");
    //	ui->comboBoxRGB->addItem("RBG");
    ui->comboBoxRGB->addItem("BGR");
    //	ui->comboBoxRGB->addItem("BRG");
    //	ui->comboBoxRGB->addItem("GRB");
    //	ui->comboBoxRGB->addItem("GBR");
    ui->comboBox565->addItem("888");
    ui->comboBox565->addItem("565");
    //	ui->comboBox565->addItem("444");
}
MainWindow::~MainWindow(){
    delete ui;
}
