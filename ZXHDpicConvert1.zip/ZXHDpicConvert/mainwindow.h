#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButtonDirPic_clicked();

    void on_pushButtonDirFont_clicked();

    void on_pushButtonDirOut_clicked();

    void on_pushButtonConvert_clicked();

private:
    Ui::MainWindow *ui;

    QString getDir(QString fname);
    void showWarning(const QString &msg);
    bool createDir(QString path);
	bool getImgInfo(char * imgBuf, QString fname, QString path);
};
#endif // MAINWINDOW_H
