#include <stdio.h>
#include <string.h>
#include <conio.h>

#include "module.h"

void prnHex(unsigned char* hex, int len){
	for(int i = 0; i < len; i++){
		printf("%02x ", hex[i]); 
	}
	printf("\n\r");
}

unsigned char plain[AES_BLOCK_SIZE] = {
	0x32, 0x88, 0x31, 0xe0,   
	0x43, 0x5a, 0x31, 0x37,  
	0xf6, 0x30, 0x98, 0x07,  
	0xa8, 0x8d, 0xa2, 0x34
}; 

void main(void){
	initAES();
	unsigned char* cipher = Encrypt(plain);
	prnHex(cipher, AES_BLOCK_SIZE);
	unsigned char* reverse_cipher = Decrypt(cipher);
	prnHex(reverse_cipher, AES_BLOCK_SIZE);
	int res = memcmp(reverse_cipher, plain, AES_BLOCK_SIZE);
	if(res)
		printf("fail");
	else
		printf("ok");


	getch();
}
