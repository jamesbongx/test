/*************************************************************
** this file is all picture struct information source file
** by fengshanlong
*************************************************************/
#include "picture.h"
#include "picture_data.h"


const picture_info_struct pic_quick_ble_info = {
	.addr = (const unsigned char *)0x00000000,
	.width = 10,
	.height = 13,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_brightness_info = {
	.addr = (const unsigned char *)0x000000d2,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_disturb_off_info = {
	.addr = (const unsigned char *)0x00000a6e,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_disturb_on_info = {
	.addr = (const unsigned char *)0x00001406,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_led_off_info = {
	.addr = (const unsigned char *)0x00001da0,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_more_info = {
	.addr = (const unsigned char *)0x00002718,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_power_1_info = {
	.addr = (const unsigned char *)0x0000309a,
	.width = 18,
	.height = 9,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_power_2_info = {
	.addr = (const unsigned char *)0x00003154,
	.width = 18,
	.height = 9,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_power_3_info = {
	.addr = (const unsigned char *)0x0000320e,
	.width = 18,
	.height = 9,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_quick_power_4_info = {
	.addr = (const unsigned char *)0x000032c8,
	.width = 18,
	.height = 9,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_today_kcal_info = {
	.addr = (const unsigned char *)0x00003382,
	.width = 12,
	.height = 15,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_today_km_info = {
	.addr = (const unsigned char *)0x000034a6,
	.width = 11,
	.height = 14,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_today_step_info = {
	.addr = (const unsigned char *)0x00003588,
	.width = 35,
	.height = 35,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sleep_all_info = {
	.addr = (const unsigned char *)0x00003c49,
	.width = 27,
	.height = 24,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sleep_deep_info = {
	.addr = (const unsigned char *)0x00003f67,
	.width = 24,
	.height = 23,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sleep_light_info = {
	.addr = (const unsigned char *)0x0000422b,
	.width = 21,
	.height = 21,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_cloudy_info = {
	.addr = (const unsigned char *)0x00004482,
	.width = 32,
	.height = 32,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_no_weather_info = {
	.addr = (const unsigned char *)0x000048f8,
	.width = 32,
	.height = 32,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_partly_cloudy_info = {
	.addr = (const unsigned char *)0x00004d84,
	.width = 32,
	.height = 32,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_rain_info = {
	.addr = (const unsigned char *)0x00005256,
	.width = 32,
	.height = 32,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_snow_info = {
	.addr = (const unsigned char *)0x000056b0,
	.width = 32,
	.height = 32,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sunny_info = {
	.addr = (const unsigned char *)0x00005b0a,
	.width = 32,
	.height = 32,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_bg_info = {
	.addr = (const unsigned char *)0x00005fe4,
	.width = 240,
	.height = 240,
	.alpha = 0,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_week_1_info = {
	.addr = (const unsigned char *)0x000221e4,
	.width = 28,
	.height = 13,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_week_2_info = {
	.addr = (const unsigned char *)0x00022628,
	.width = 24,
	.height = 13,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_week_3_info = {
	.addr = (const unsigned char *)0x000229d0,
	.width = 28,
	.height = 13,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_week_4_info = {
	.addr = (const unsigned char *)0x00022e14,
	.width = 24,
	.height = 13,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_week_5_info = {
	.addr = (const unsigned char *)0x000231bc,
	.width = 17,
	.height = 13,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_week_6_info = {
	.addr = (const unsigned char *)0x00023453,
	.width = 23,
	.height = 13,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_week_7_info = {
	.addr = (const unsigned char *)0x000237d4,
	.width = 24,
	.height = 13,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_min_0_info = {
	.addr = (const unsigned char *)0x00023b7c,
	.width = (240<<8)|240,
	.height = 11460,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_min_1_info = {
	.addr = (const unsigned char *)0x00026840,
	.width = (240<<8)|240,
	.height = 11250,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_min_2_info = {
	.addr = (const unsigned char *)0x00029432,
	.width = (240<<8)|240,
	.height = 11285,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_min_3_info = {
	.addr = (const unsigned char *)0x0002c047,
	.width = (240<<8)|240,
	.height = 11315,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_min_4_info = {
	.addr = (const unsigned char *)0x0002ec7a,
	.width = (240<<8)|240,
	.height = 11315,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_min_5_info = {
	.addr = (const unsigned char *)0x000318ad,
	.width = (240<<8)|240,
	.height = 11470,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_min_6_info = {
	.addr = (const unsigned char *)0x0003457b,
	.width = (240<<8)|240,
	.height = 11295,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_min_7_info = {
	.addr = (const unsigned char *)0x0003719a,
	.width = (240<<8)|240,
	.height = 11275,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_hour_0_info = {
	.addr = (const unsigned char *)0x00039da5,
	.width = (240<<8)|240,
	.height = 8420,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_hour_1_info = {
	.addr = (const unsigned char *)0x0003be89,
	.width = (240<<8)|240,
	.height = 8395,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_hour_2_info = {
	.addr = (const unsigned char *)0x0003df54,
	.width = (240<<8)|240,
	.height = 8440,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_hour_3_info = {
	.addr = (const unsigned char *)0x0004004c,
	.width = (240<<8)|240,
	.height = 8440,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_hour_4_info = {
	.addr = (const unsigned char *)0x00042144,
	.width = (240<<8)|240,
	.height = 8470,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_hour_5_info = {
	.addr = (const unsigned char *)0x0004425a,
	.width = (240<<8)|240,
	.height = 8455,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_hour_6_info = {
	.addr = (const unsigned char *)0x00046361,
	.width = (240<<8)|240,
	.height = 8445,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main_1_hour_7_info = {
	.addr = (const unsigned char *)0x0004845e,
	.width = (240<<8)|240,
	.height = 8370,
	.alpha = 4,
	.external_flag = 1,
};

const picture_info_struct pic_main2_bg_info = {
	.addr = (const unsigned char *)0x0004a510,
	.width = 240,
	.height = 240,
	.alpha = 0,
	.external_flag = 1,
};

const picture_info_struct pic_main2_sec_info = {
	.addr = (const unsigned char *)0x00066710,
	.width = 21,
	.height = 21,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_heart_high_info = {
	.addr = (const unsigned char *)0x00066c3b,
	.width = 11,
	.height = 11,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_heart_little_info = {
	.addr = (const unsigned char *)0x00066cf8,
	.width = 30,
	.height = 30,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_heart_low_info = {
	.addr = (const unsigned char *)0x000671c6,
	.width = 11,
	.height = 11,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_BP_check_bg_info = {
	.addr = (const unsigned char *)0x00067281,
	.width = 100,
	.height = 30,
	.alpha = 0,
	.external_flag = 1,
};

const picture_info_struct pic_BP_check_little_info = {
	.addr = (const unsigned char *)0x000689f1,
	.width = 14,
	.height = 18,
	.alpha = 1,
	.external_flag = 1,
};

const picture_info_struct pic_BP_little_info = {
	.addr = (const unsigned char *)0x00068ce5,
	.width = 26,
	.height = 31,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_O2_little_info = {
	.addr = (const unsigned char *)0x0006914d,
	.width = 33,
	.height = 32,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_music_info = {
	.addr = (const unsigned char *)0x000696d9,
	.width = 206,
	.height = 62,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_music_last_info = {
	.addr = (const unsigned char *)0x0006c9d3,
	.width = 40,
	.height = 40,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_music_next_info = {
	.addr = (const unsigned char *)0x0006d0bf,
	.width = 40,
	.height = 40,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_music_pp_info = {
	.addr = (const unsigned char *)0x0006d7ad,
	.width = 60,
	.height = 60,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_black_point_1_info = {
	.addr = (const unsigned char *)pic_black_point_1_data,
	.width = 8,
	.height = 8,
	.alpha = 0,
	.external_flag = 0,
};

const picture_info_struct pic_light_point_1_info = {
	.addr = (const unsigned char *)pic_light_point_1_data,
	.width = 8,
	.height = 8,
	.alpha = 0,
	.external_flag = 0,
};

const picture_info_struct pic_more_info = {
	.addr = (const unsigned char *)0x0006e6b1,
	.width = 99,
	.height = 99,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_about_info = {
	.addr = (const unsigned char *)0x00070e36,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_alarm_info = {
	.addr = (const unsigned char *)0x00071864,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_breath_info = {
	.addr = (const unsigned char *)0x0007228c,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_find_phone_info = {
	.addr = (const unsigned char *)0x00072cd6,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_lcd_timeout_info = {
	.addr = (const unsigned char *)0x00073708,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_photograph_info = {
	.addr = (const unsigned char *)0x0007412a,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_QR_code_info = {
	.addr = (const unsigned char *)0x00074b12,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_reset_info = {
	.addr = (const unsigned char *)0x000754a4,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_shutdown_info = {
	.addr = (const unsigned char *)0x00075f0e,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_sport_info = {
	.addr = (const unsigned char *)0x0007693a,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_stopwatch_info = {
	.addr = (const unsigned char *)0x000773c2,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_more_watchface_select_info = {
	.addr = (const unsigned char *)0x00077d8c,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_find_phone_info = {
	.addr = (const unsigned char *)0x000787b2,
	.width = 92,
	.height = 99,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_no_little_info = {
	.addr = (const unsigned char *)0x0007ac48,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_pause_little_info = {
	.addr = (const unsigned char *)0x0007b5c0,
	.width = 49,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_photograph_info = {
	.addr = (const unsigned char *)0x0007bff2,
	.width = 99,
	.height = 99,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_QR_code_info = {
	.addr = (const unsigned char *)0x0007e73d,
	.width = 120,
	.height = 120,
	.alpha = 0,
	.external_flag = 1,
};

const picture_info_struct pic_reset_little_info = {
	.addr = (const unsigned char *)0x000857bd,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_start_little_info = {
	.addr = (const unsigned char *)0x00086171,
	.width = 49,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_yes_little_info = {
	.addr = (const unsigned char *)0x00086b5d,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_badminton_info = {
	.addr = (const unsigned char *)0x0008754d,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_basketball_info = {
	.addr = (const unsigned char *)0x00087fd9,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_climb_info = {
	.addr = (const unsigned char *)0x00088ab9,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_continue_info = {
	.addr = (const unsigned char *)0x00089569,
	.width = 60,
	.height = 60,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_cycling_info = {
	.addr = (const unsigned char *)0x0008a4a9,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_finish_info = {
	.addr = (const unsigned char *)0x0008af05,
	.width = 60,
	.height = 60,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_football_info = {
	.addr = (const unsigned char *)0x0008be23,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_run_info = {
	.addr = (const unsigned char *)0x0008c8b3,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_skip_info = {
	.addr = (const unsigned char *)0x0008d323,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_font_bpm_info = {
	.addr = (const unsigned char *)0x0008dd77,
	.width = 35,
	.height = 13,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_font_kcal_info = {
	.addr = (const unsigned char *)0x0008df60,
	.width = 44,
	.height = 13,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_font_km_info = {
	.addr = (const unsigned char *)0x0008e1be,
	.width = 24,
	.height = 13,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_font_steps_info = {
	.addr = (const unsigned char *)0x0008e318,
	.width = 53,
	.height = 13,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_swim_info = {
	.addr = (const unsigned char *)0x0008e5eb,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_walk_info = {
	.addr = (const unsigned char *)0x0008f06f,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_wear_info = {
	.addr = (const unsigned char *)0x0008facb,
	.width = 118,
	.height = 60,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_yoga_info = {
	.addr = (const unsigned char *)0x00091875,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_add_info = {
	.addr = (const unsigned char *)0x000922ff,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_info = {
	.addr = (const unsigned char *)0x00092ccf,
	.width = 99,
	.height = 99,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_call_info = {
	.addr = (const unsigned char *)0x0009551a,
	.width = 80,
	.height = 80,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_charger_info = {
	.addr = (const unsigned char *)0x00096fc4,
	.width = 124,
	.height = 124,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_delete_info = {
	.addr = (const unsigned char *)0x0009add6,
	.width = 48,
	.height = 48,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_drink_info = {
	.addr = (const unsigned char *)0x0009b7a6,
	.width = 99,
	.height = 99,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_find_device_info = {
	.addr = (const unsigned char *)0x0009dff1,
	.width = 99,
	.height = 99,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_low_power_info = {
	.addr = (const unsigned char *)0x000a083c,
	.width = 113,
	.height = 113,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_missed_call_info = {
	.addr = (const unsigned char *)0x000a3bbf,
	.width = 78,
	.height = 32,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sedentary_remind_info = {
	.addr = (const unsigned char *)0x000a4681,
	.width = 99,
	.height = 99,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_0_info = {
	.addr = (const unsigned char *)0x000a6ecc,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_1_info = {
	.addr = (const unsigned char *)0x000a71a3,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_2_info = {
	.addr = (const unsigned char *)0x000a7472,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_3_info = {
	.addr = (const unsigned char *)0x000a7749,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_4_info = {
	.addr = (const unsigned char *)0x000a7a20,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_5_info = {
	.addr = (const unsigned char *)0x000a7cf7,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_6_info = {
	.addr = (const unsigned char *)0x000a7fce,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_7_info = {
	.addr = (const unsigned char *)0x000a82a5,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_8_info = {
	.addr = (const unsigned char *)0x000a857c,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_9_info = {
	.addr = (const unsigned char *)0x000a8853,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_delete_info = {
	.addr = (const unsigned char *)0x000a8b2a,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_34_line_info = {
	.addr = (const unsigned char *)0x000a8df3,
	.width = 21,
	.height = 33,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_0_info = {
	.addr = (const unsigned char *)0x000a90c8,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_1_info = {
	.addr = (const unsigned char *)0x000a93d6,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_2_info = {
	.addr = (const unsigned char *)0x000a96dc,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_3_info = {
	.addr = (const unsigned char *)0x000a99ea,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_4_info = {
	.addr = (const unsigned char *)0x000a9cf8,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_5_info = {
	.addr = (const unsigned char *)0x000aa006,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_6_info = {
	.addr = (const unsigned char *)0x000aa314,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_7_info = {
	.addr = (const unsigned char *)0x000aa622,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_8_info = {
	.addr = (const unsigned char *)0x000aa92e,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_9_info = {
	.addr = (const unsigned char *)0x000aac3c,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_C_info = {
	.addr = (const unsigned char *)0x000aaf4a,
	.width = 9,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_delete_info = {
	.addr = (const unsigned char *)0x000ab09c,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_36_color_line_info = {
	.addr = (const unsigned char *)0x000ab396,
	.width = 22,
	.height = 34,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_90_1_info = {
	.addr = (const unsigned char *)0x000ab6a4,
	.width = 49,
	.height = 71,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_90_2_info = {
	.addr = (const unsigned char *)0x000ac45b,
	.width = 49,
	.height = 71,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_90_3_info = {
	.addr = (const unsigned char *)0x000ad214,
	.width = 49,
	.height = 71,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_0_info = {
	.addr = (const unsigned char *)0x000adfcd,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_1_info = {
	.addr = (const unsigned char *)0x000ae493,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_2_info = {
	.addr = (const unsigned char *)0x000ae953,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_3_info = {
	.addr = (const unsigned char *)0x000aee19,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_4_info = {
	.addr = (const unsigned char *)0x000af2df,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_5_info = {
	.addr = (const unsigned char *)0x000af7a5,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_6_info = {
	.addr = (const unsigned char *)0x000afc6b,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_7_info = {
	.addr = (const unsigned char *)0x000b0131,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_8_info = {
	.addr = (const unsigned char *)0x000b05f7,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_9_info = {
	.addr = (const unsigned char *)0x000b0abd,
	.width = 27,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_point_info = {
	.addr = (const unsigned char *)0x000b0f83,
	.width = 10,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_alarm_two_point_info = {
	.addr = (const unsigned char *)0x000b1145,
	.width = 10,
	.height = 44,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_0_info = {
	.addr = (const unsigned char *)0x000b1309,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_1_info = {
	.addr = (const unsigned char *)0x000b1427,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_2_info = {
	.addr = (const unsigned char *)0x000b1543,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_3_info = {
	.addr = (const unsigned char *)0x000b1667,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_4_info = {
	.addr = (const unsigned char *)0x000b1791,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_5_info = {
	.addr = (const unsigned char *)0x000b18b5,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_6_info = {
	.addr = (const unsigned char *)0x000b19df,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_7_info = {
	.addr = (const unsigned char *)0x000b1b09,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_8_info = {
	.addr = (const unsigned char *)0x000b1c2f,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_9_info = {
	.addr = (const unsigned char *)0x000b1d59,
	.width = 12,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_delete_info = {
	.addr = (const unsigned char *)0x000b1e83,
	.width = 8,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_data_point_info = {
	.addr = (const unsigned char *)0x000b1f3d,
	.width = 6,
	.height = 22,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_0_info = {
	.addr = (const unsigned char *)0x000b1fd1,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_1_info = {
	.addr = (const unsigned char *)0x000b239f,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_2_info = {
	.addr = (const unsigned char *)0x000b276f,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_3_info = {
	.addr = (const unsigned char *)0x000b2b43,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_4_info = {
	.addr = (const unsigned char *)0x000b2f17,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_5_info = {
	.addr = (const unsigned char *)0x000b32eb,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_6_info = {
	.addr = (const unsigned char *)0x000b36bf,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_7_info = {
	.addr = (const unsigned char *)0x000b3a93,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_8_info = {
	.addr = (const unsigned char *)0x000b3e67,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_9_info = {
	.addr = (const unsigned char *)0x000b423b,
	.width = 22,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

const picture_info_struct pic_sport_time_point_info = {
	.addr = (const unsigned char *)0x000b460f,
	.width = 14,
	.height = 43,
	.alpha = 3,
	.external_flag = 1,
};

