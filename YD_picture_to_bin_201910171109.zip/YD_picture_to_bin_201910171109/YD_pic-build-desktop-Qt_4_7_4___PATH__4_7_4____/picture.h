/*************************************************************
** this file is all picture struct information head file
** by fengshanlong
*************************************************************/
#ifndef _PICTURE_H
#define _PICTURE_H


#define PIC_CRC16		0xAC1C
#define PIC_HEAD_SIZE	16
#define PIC_OFFSET		0x00197000


#define	NEW_SONG16X16_MAP_OFFSET		0x00000000


typedef struct
{
	const unsigned char *addr;
	const unsigned short width;
	const unsigned short height;
	const unsigned char alpha;//0: no alpha, 1: has alpha, 2: point display, 3: 8bit(256 color), 4: alpha point.
	const unsigned char external_flag;//0: mcu flash, 1: external spi flash or emmc.
}picture_info_struct;


extern const picture_info_struct pic_quick_ble_info;
extern const picture_info_struct pic_quick_brightness_info;
extern const picture_info_struct pic_quick_disturb_off_info;
extern const picture_info_struct pic_quick_disturb_on_info;
extern const picture_info_struct pic_quick_led_off_info;
extern const picture_info_struct pic_quick_more_info;
extern const picture_info_struct pic_quick_power_1_info;
extern const picture_info_struct pic_quick_power_2_info;
extern const picture_info_struct pic_quick_power_3_info;
extern const picture_info_struct pic_quick_power_4_info;
extern const picture_info_struct pic_today_kcal_info;
extern const picture_info_struct pic_today_km_info;
extern const picture_info_struct pic_today_step_info;
extern const picture_info_struct pic_sleep_all_info;
extern const picture_info_struct pic_sleep_deep_info;
extern const picture_info_struct pic_sleep_light_info;
extern const picture_info_struct pic_cloudy_info;
extern const picture_info_struct pic_no_weather_info;
extern const picture_info_struct pic_partly_cloudy_info;
extern const picture_info_struct pic_rain_info;
extern const picture_info_struct pic_snow_info;
extern const picture_info_struct pic_sunny_info;
extern const picture_info_struct pic_main_1_bg_info;
extern const picture_info_struct pic_main_1_week_1_info;
extern const picture_info_struct pic_main_1_week_2_info;
extern const picture_info_struct pic_main_1_week_3_info;
extern const picture_info_struct pic_main_1_week_4_info;
extern const picture_info_struct pic_main_1_week_5_info;
extern const picture_info_struct pic_main_1_week_6_info;
extern const picture_info_struct pic_main_1_week_7_info;
extern const picture_info_struct pic_main_1_min_0_info;
extern const picture_info_struct pic_main_1_min_1_info;
extern const picture_info_struct pic_main_1_min_2_info;
extern const picture_info_struct pic_main_1_min_3_info;
extern const picture_info_struct pic_main_1_min_4_info;
extern const picture_info_struct pic_main_1_min_5_info;
extern const picture_info_struct pic_main_1_min_6_info;
extern const picture_info_struct pic_main_1_min_7_info;
extern const picture_info_struct pic_main_1_hour_0_info;
extern const picture_info_struct pic_main_1_hour_1_info;
extern const picture_info_struct pic_main_1_hour_2_info;
extern const picture_info_struct pic_main_1_hour_3_info;
extern const picture_info_struct pic_main_1_hour_4_info;
extern const picture_info_struct pic_main_1_hour_5_info;
extern const picture_info_struct pic_main_1_hour_6_info;
extern const picture_info_struct pic_main_1_hour_7_info;
extern const picture_info_struct pic_main2_bg_info;
extern const picture_info_struct pic_main2_sec_info;
extern const picture_info_struct pic_heart_high_info;
extern const picture_info_struct pic_heart_little_info;
extern const picture_info_struct pic_heart_low_info;
extern const picture_info_struct pic_BP_check_bg_info;
extern const picture_info_struct pic_BP_check_little_info;
extern const picture_info_struct pic_BP_little_info;
extern const picture_info_struct pic_O2_little_info;
extern const picture_info_struct pic_music_info;
extern const picture_info_struct pic_music_last_info;
extern const picture_info_struct pic_music_next_info;
extern const picture_info_struct pic_music_pp_info;
extern const picture_info_struct pic_black_point_1_info;
extern const picture_info_struct pic_light_point_1_info;
extern const picture_info_struct pic_more_info;
extern const picture_info_struct pic_more_about_info;
extern const picture_info_struct pic_more_alarm_info;
extern const picture_info_struct pic_more_breath_info;
extern const picture_info_struct pic_more_find_phone_info;
extern const picture_info_struct pic_more_lcd_timeout_info;
extern const picture_info_struct pic_more_photograph_info;
extern const picture_info_struct pic_more_QR_code_info;
extern const picture_info_struct pic_more_reset_info;
extern const picture_info_struct pic_more_shutdown_info;
extern const picture_info_struct pic_more_sport_info;
extern const picture_info_struct pic_more_stopwatch_info;
extern const picture_info_struct pic_more_watchface_select_info;
extern const picture_info_struct pic_find_phone_info;
extern const picture_info_struct pic_no_little_info;
extern const picture_info_struct pic_pause_little_info;
extern const picture_info_struct pic_photograph_info;
extern const picture_info_struct pic_QR_code_info;
extern const picture_info_struct pic_reset_little_info;
extern const picture_info_struct pic_start_little_info;
extern const picture_info_struct pic_yes_little_info;
extern const picture_info_struct pic_badminton_info;
extern const picture_info_struct pic_basketball_info;
extern const picture_info_struct pic_climb_info;
extern const picture_info_struct pic_continue_info;
extern const picture_info_struct pic_cycling_info;
extern const picture_info_struct pic_finish_info;
extern const picture_info_struct pic_football_info;
extern const picture_info_struct pic_run_info;
extern const picture_info_struct pic_skip_info;
extern const picture_info_struct pic_sport_font_bpm_info;
extern const picture_info_struct pic_sport_font_kcal_info;
extern const picture_info_struct pic_sport_font_km_info;
extern const picture_info_struct pic_sport_font_steps_info;
extern const picture_info_struct pic_swim_info;
extern const picture_info_struct pic_walk_info;
extern const picture_info_struct pic_wear_info;
extern const picture_info_struct pic_yoga_info;
extern const picture_info_struct pic_add_info;
extern const picture_info_struct pic_alarm_info;
extern const picture_info_struct pic_call_info;
extern const picture_info_struct pic_charger_info;
extern const picture_info_struct pic_delete_info;
extern const picture_info_struct pic_drink_info;
extern const picture_info_struct pic_find_device_info;
extern const picture_info_struct pic_low_power_info;
extern const picture_info_struct pic_missed_call_info;
extern const picture_info_struct pic_sedentary_remind_info;
extern const picture_info_struct pic_34_0_info;
extern const picture_info_struct pic_34_1_info;
extern const picture_info_struct pic_34_2_info;
extern const picture_info_struct pic_34_3_info;
extern const picture_info_struct pic_34_4_info;
extern const picture_info_struct pic_34_5_info;
extern const picture_info_struct pic_34_6_info;
extern const picture_info_struct pic_34_7_info;
extern const picture_info_struct pic_34_8_info;
extern const picture_info_struct pic_34_9_info;
extern const picture_info_struct pic_34_delete_info;
extern const picture_info_struct pic_34_line_info;
extern const picture_info_struct pic_36_color_0_info;
extern const picture_info_struct pic_36_color_1_info;
extern const picture_info_struct pic_36_color_2_info;
extern const picture_info_struct pic_36_color_3_info;
extern const picture_info_struct pic_36_color_4_info;
extern const picture_info_struct pic_36_color_5_info;
extern const picture_info_struct pic_36_color_6_info;
extern const picture_info_struct pic_36_color_7_info;
extern const picture_info_struct pic_36_color_8_info;
extern const picture_info_struct pic_36_color_9_info;
extern const picture_info_struct pic_36_color_C_info;
extern const picture_info_struct pic_36_color_delete_info;
extern const picture_info_struct pic_36_color_line_info;
extern const picture_info_struct pic_90_1_info;
extern const picture_info_struct pic_90_2_info;
extern const picture_info_struct pic_90_3_info;
extern const picture_info_struct pic_alarm_0_info;
extern const picture_info_struct pic_alarm_1_info;
extern const picture_info_struct pic_alarm_2_info;
extern const picture_info_struct pic_alarm_3_info;
extern const picture_info_struct pic_alarm_4_info;
extern const picture_info_struct pic_alarm_5_info;
extern const picture_info_struct pic_alarm_6_info;
extern const picture_info_struct pic_alarm_7_info;
extern const picture_info_struct pic_alarm_8_info;
extern const picture_info_struct pic_alarm_9_info;
extern const picture_info_struct pic_alarm_point_info;
extern const picture_info_struct pic_alarm_two_point_info;
extern const picture_info_struct pic_sport_data_0_info;
extern const picture_info_struct pic_sport_data_1_info;
extern const picture_info_struct pic_sport_data_2_info;
extern const picture_info_struct pic_sport_data_3_info;
extern const picture_info_struct pic_sport_data_4_info;
extern const picture_info_struct pic_sport_data_5_info;
extern const picture_info_struct pic_sport_data_6_info;
extern const picture_info_struct pic_sport_data_7_info;
extern const picture_info_struct pic_sport_data_8_info;
extern const picture_info_struct pic_sport_data_9_info;
extern const picture_info_struct pic_sport_data_delete_info;
extern const picture_info_struct pic_sport_data_point_info;
extern const picture_info_struct pic_sport_time_0_info;
extern const picture_info_struct pic_sport_time_1_info;
extern const picture_info_struct pic_sport_time_2_info;
extern const picture_info_struct pic_sport_time_3_info;
extern const picture_info_struct pic_sport_time_4_info;
extern const picture_info_struct pic_sport_time_5_info;
extern const picture_info_struct pic_sport_time_6_info;
extern const picture_info_struct pic_sport_time_7_info;
extern const picture_info_struct pic_sport_time_8_info;
extern const picture_info_struct pic_sport_time_9_info;
extern const picture_info_struct pic_sport_time_point_info;


#endif //_PICTURE_H

