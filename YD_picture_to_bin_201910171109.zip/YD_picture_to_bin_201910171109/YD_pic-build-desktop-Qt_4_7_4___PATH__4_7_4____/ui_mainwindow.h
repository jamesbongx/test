/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Thu Oct 17 21:16:52 2019
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLineEdit *lineEdit;
    QPushButton *pushButton_dir;
    QTableWidget *tableWidget;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *lineEdit_bin;
    QPushButton *pushButton_bin;
    QTableWidget *tableWidget_bin;
    QHBoxLayout *horizontalLayout_2;
    QCheckBox *checkBox_flash;
    QCheckBox *checkBox_alpha;
    QPushButton *pushButton_refresh;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(758, 574);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        lineEdit = new QLineEdit(centralWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\260\345\256\213\344\275\223"));
        lineEdit->setFont(font);

        horizontalLayout->addWidget(lineEdit);

        pushButton_dir = new QPushButton(centralWidget);
        pushButton_dir->setObjectName(QString::fromUtf8("pushButton_dir"));

        horizontalLayout->addWidget(pushButton_dir);


        verticalLayout->addLayout(horizontalLayout);

        tableWidget = new QTableWidget(centralWidget);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        verticalLayout->addWidget(tableWidget);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        lineEdit_bin = new QLineEdit(centralWidget);
        lineEdit_bin->setObjectName(QString::fromUtf8("lineEdit_bin"));
        lineEdit_bin->setFont(font);

        horizontalLayout_3->addWidget(lineEdit_bin);

        pushButton_bin = new QPushButton(centralWidget);
        pushButton_bin->setObjectName(QString::fromUtf8("pushButton_bin"));

        horizontalLayout_3->addWidget(pushButton_bin);


        verticalLayout->addLayout(horizontalLayout_3);

        tableWidget_bin = new QTableWidget(centralWidget);
        tableWidget_bin->setObjectName(QString::fromUtf8("tableWidget_bin"));

        verticalLayout->addWidget(tableWidget_bin);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        checkBox_flash = new QCheckBox(centralWidget);
        checkBox_flash->setObjectName(QString::fromUtf8("checkBox_flash"));
        checkBox_flash->setChecked(false);

        horizontalLayout_2->addWidget(checkBox_flash);

        checkBox_alpha = new QCheckBox(centralWidget);
        checkBox_alpha->setObjectName(QString::fromUtf8("checkBox_alpha"));

        horizontalLayout_2->addWidget(checkBox_alpha);

        pushButton_refresh = new QPushButton(centralWidget);
        pushButton_refresh->setObjectName(QString::fromUtf8("pushButton_refresh"));

        horizontalLayout_2->addWidget(pushButton_refresh);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        pushButton->setFont(font1);

        horizontalLayout_2->addWidget(pushButton);


        verticalLayout->addLayout(horizontalLayout_2);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "\345\233\276\347\211\207\350\275\254\346\215\242\345\267\245\345\205\267V2.2(\344\275\234\350\200\205\357\274\232\345\206\257\345\226\204\351\276\231)", 0, QApplication::UnicodeUTF8));
        pushButton_dir->setText(QApplication::translate("MainWindow", "\346\226\207\344\273\266\345\244\271...", 0, QApplication::UnicodeUTF8));
        pushButton_bin->setText(QApplication::translate("MainWindow", "bin\346\226\207\344\273\266\345\244\271", 0, QApplication::UnicodeUTF8));
        checkBox_flash->setText(QApplication::translate("MainWindow", "\345\244\226\351\203\250flash", 0, QApplication::UnicodeUTF8));
        checkBox_alpha->setText(QApplication::translate("MainWindow", "\351\200\217\346\230\216\345\272\246", 0, QApplication::UnicodeUTF8));
        pushButton_refresh->setText(QApplication::translate("MainWindow", "\345\210\267\346\226\260", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("MainWindow", "\345\274\200\345\247\213", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
