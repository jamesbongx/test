#if !defined(MODULE_H)
#define MODULE_H

#define AES_BLOCK_SIZE	16

extern unsigned char* Encrypt(unsigned char* plaintext);
extern unsigned char* Decrypt(unsigned char* cipher);
extern void initAES(void);

#endif	//!defined(MODULE_H)