
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QFile"
#include "stdio.h"
#include "QByteArray"
#include "QImage"
#include "QDir"
#include "QFileInfoList"
#include "QFileDialog"
#include "QMessageBox"
#include "QTextCodec"

#define STR_ALPHA_YES "yes"
#define STR_ALPHA_NO "no"
#define STR_FORCE_MCU_FLASH "force_mcu"
#define STR_MCU_FLASH "mcu"
#define STR_SPI_FLASH "spi"
#define STR_NO_FLASH "-"

char buf[100];
int convertImg(QImage * img)
{
	unsigned int R, G, B, i;
	unsigned int color;
	unsigned char alpha;

	alpha = img->constBits()[len + 3];
	R	= img->constBits()[len + 0];
	G	= img->constBits()[len + 1];
	B	= img->constBits()[len + 2];
	if (ui->comboBoxRGB->currentIndex() == 1) {
		i	= R;
		R	= B;
		B	= i;
	}

	i	= 0;
	if (STR_ALPHA_YES == ui->tableWidget->item(n, TABLE_COLUMN_ALPHA)->text()) {
		buf[i++] = alpha;
	}
	if (ui->comboBox565->currentIndex() == 1) {
		buf[i++] = R;
		buf[i++] = G;
		buf[i++] = B;
	}
	else {
		color = ((R >> 3) << 11) + ((G >> 2) << 5) + ((B >> 3) << 0);
		buf[i++] = (color >> 8) & 0xFF;
		buf[i++] = (color >> 0) & 0xFF;
	}
	return i;
}
int byteCount(QImage * img)
{
	return img->bytesPerLine() *img->height();
}
/**
  * @brief	:crc16 calculation function
  * @param	:crc16 --> the first crc16 value,it can fill 0 at first use
  *			:buf --> the calculate data point
  *			:len --> the calculate data length
  * @retval :return the crc16 value
  * @author :ZXHD
  */
unsigned short calculate_crc16(unsigned short crc16, char * buf, unsigned int len)
{
	unsigned short msb;
	unsigned short data;
	unsigned short gx = 0x8005;
	unsigned int i = 0, j = 0;

	if (len == 0) {
		return 0;

	}

	if (NULL == buf) {
		qDebug("%s,the data is NULL\r\n", __FUNCTION__);
		return 0;
	}

	for (i = 0; i < len; ++i) {
		data = (unsigned short)
		buf[i];
		data = data << 8;
		crc16 = crc16 ^ data;
		j	= 0;
		do {
			msb = crc16 & 0x8000;
			crc16 = crc16 << 1;
			if (msb == 0x8000) {
				crc16 = crc16 ^ gx;
			}
			j++;
		}
		while(j < 8);
	}
	return crc16;
}

MainWindow::MainWindow(QWidget * parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
	ui->setupUi(this);

	ui->comboBoxRGB->addItem("RGB");
	//	ui->comboBoxRGB->addItem("RBG");
	ui->comboBoxRGB->addItem("BGR");
	//	ui->comboBoxRGB->addItem("BRG");
	//	ui->comboBoxRGB->addItem("GRB");
	//	ui->comboBoxRGB->addItem("GBR");
	ui->comboBox565->addItem("888");
	ui->comboBox565->addItem("565");
	//	ui->comboBox565->addItem("444");
}
MainWindow::~MainWindow()
{
	delete ui;
}

bool MainWindow::scanData(const QDir & fromDir, const QStringList & filters)
{
	QFileInfoList fileInfoList = fromDir.entryInfoList(filters, QDir::AllDirs | QDir::Files);

	foreach (QFileInfo fileInfo, fileInfoList) {
		if (fileInfo.fileName() == "." || fileInfo.fileName() == "..") {
			continue;
		}
		if (fileInfo.isDir()) {
			if (!scanData(fileInfo.filePath(), filters)) {
				return false;
			}
		}
		else {
			filePathList.append(fileInfo.filePath());
			fileNameList.append("pic_" + fileInfo.baseName());
			fileCompleteSuffixNameList.append(fileInfo.completeSuffix());
		}
	}
	return true;
}

bool MainWindow::scanData_bin(const QDir & fromDir, const QStringList & filters)
{
	QFileInfoList fileInfoList = fromDir.entryInfoList(filters, QDir::AllDirs | QDir::Files);

	foreach (QFileInfo fileInfo, fileInfoList) {
		if (fileInfo.fileName() == "." || fileInfo.fileName() == "..") {
			continue;
		}
		if (fileInfo.isDir()) {
			if (!scanData_bin(fileInfo.filePath(), filters)) {
				return false;
			}
		}
		else {
			filePathList_bin.append(fileInfo.filePath());
			fileNameList_bin.append(fileInfo.baseName());
			fileCompleteSuffixNameList_bin.append(fileInfo.completeSuffix());
		}
	}
	return true;
}

void MainWindow::on_pushButton_clicked()
{
	QFile picture_file;
	QByteArray picture_data;
	QFile font_file;
	QByteArray font_data;
	unsigned int n = 0, pos = 0, last_pos = 0;
	unsigned char bit_point = 0;
	unsigned short crc16 = 0;
	unsigned int pic_offset = 0;
	QStringList checkFilePathList, checkFileNameList;
	QStringList checkFilePathList_bin, checkFileNameList_bin;

	for (int i = 0; i < ui->tableWidget->rowCount(); i++) {
		//?�载所?�?�?�片，? ?�� ?�表示?�片?�?�?�内??lash� ，?�� ?�表示?�片?�?�?��???lash� 
		//if(Qt::Checked == ui->listWidget->item(i)->checkState())
		{
			checkFilePathList.append(filePathList.at(i));
			checkFileNameList.append(fileNameList.at(i));
		}
	}
	for (int i = 0; i < ui->tableWidget_bin->rowCount(); i++) {
		//load all bin file
		{
			checkFilePathList_bin.append(filePathList_bin.at(i));
			checkFileNameList_bin.append(fileNameList_bin.at(i));
		}
	}
	//====================== picture.bin file create ==============
	picture_data.resize(0);
	qDebug("set picture.bin file");

	n	= 0;
	QVector <int> dataLen(2);
	//copy fileInfoList to fileInfo
	foreach (QString fileInfo, checkFilePathList) {
		QImage * img = new QImage();

		img->load(fileInfo);
		unsigned char alpha = 0;

		if (STR_SPI_FLASH == ui->tableWidget->item(n, TABLE_COLUMN_FLASH)->text()) {
			unsigned int x_align_size = (img->width() + 3) / 4 * 4; //4 bytes aligned

			for (int len = 0; len < byteCount(img); len += img->depth() / 8) {
				//byte aligned, skip padding bytes
				if ((len % x_align_size) >= (unsigned int)
				img->width()) {
					continue;
				}
				bit_point = convertImg(img);
				picture_data.insert(picture_data.size(), buf, bit_point);
			}
		}
		n++;
	}
	picture_file.setFileName("picture.bin");
	picture_file.open(QIODevice::ReadWrite);
	picture_file.resize(0);
	picture_file.write(picture_data);
	picture_file.close();
	font_data.clear();
	pic_offset = 0;
	fileLenList_bin.clear();
	for (int i = 0; i < ui->tableWidget_bin->rowCount(); i++) {
		//load all bin file
		unsigned font_file_len = 0;
		QString fileName = filePathList_bin.at(i);

		font_file.setFileName(fileName);
		if (false == font_file.open(QIODevice::ReadWrite)) {
			qDebug("open file fail");
			QMessageBox::warning(this, 
				tr("�?��"), 
				tr("字库?�件�?存??"), 
				QMessageBox::Yes);
			return;
		}
		font_file_len = font_file.size();
		font_file.seek(0);
		font_data.insert(font_data.size(), font_file.readAll());
		font_file.close();

		snprintf(buf, sizeof(buf), "#define\t%s_OFFSET\t\t0x%08X\r\n", 
			fileNameList_bin.at(i).toUpper().toLatin1().data(), pic_offset);
		fileLenList_bin.append(buf);
		pic_offset += font_file_len;
	}
	if (ui->tableWidget_bin->rowCount() > 0) {
		//pad to 4K
		char temp[4096] = {
			0
		};
		memset(temp, 0xFF, sizeof(temp));
		unsigned int remind_size = (font_data.size() + 16) % 4096;

		if (remind_size > 0) {
			picture_data.insert(0, temp, 4096 - remind_size);
			pic_offset = (font_data.size() + 16) + (4096 - remind_size);
		}
		else {
			pic_offset = (font_data.size() + 16);
		}
		picture_data.insert(0, font_data);
	}
	else {
		pic_offset = 16;
	}
	crc16 = calculate_crc16(0, picture_data.data(), picture_data.size());

	//add CRC in front
	memset(buf, 0, sizeof(buf));
	buf[0] = (crc16 >> 0) & 0xFF;
	buf[1] = (crc16 >> 8) & 0xFF;
	buf[2] = (picture_data.size() >> 0) & 0xFF;
	buf[3] = (picture_data.size() >> 8) & 0xFF;
	buf[4] = (picture_data.size() >> 16) & 0xFF;
	buf[5] = (picture_data.size() >> 24) & 0xFF;
	picture_data.insert(0, buf, 16);

	//write font_picture bin file
	picture_file.setFileName("picture_font_merge.bin");
	picture_file.open(QIODevice::ReadWrite);
	picture_file.resize(0);
	picture_file.write(picture_data);
	picture_file.close();
	//===========================================================
	//====================== picture_data.c file create =========
	picture_file.setFileName("picture_data.c");
	picture_file.open(QIODevice::ReadWrite);
	picture_file.resize(0);
	picture_data.resize(0);
	qDebug("set picture_data.c file");

	snprintf(buf, sizeof(buf), "/*************************************************************\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "** this file is all picture data source file\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "** by ZXHD\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "*************************************************************/\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "\r\n\r\n");
	picture_data.insert(picture_data.size(), buf);

	n	= 0;
	//copy fileInfoList to fileInfo
	foreach (QString fileInfo, checkFilePathList) {
		QImage * img = new QImage();

		img->load(fileInfo);

		pos = 0;
		last_pos = 0;

		snprintf(buf, sizeof(buf), "const unsigned char %s_data[%d*%d*%d] = \r\n{\r\n\t", 
			checkFileNameList.at(n).toLocal8Bit().data(), 
			img->width(), img->height(), bit_point);
		picture_data.insert(picture_data.size(), buf);

		unsigned int x_align_size = (img->width() + 3) / 4 * 4; //?�片每行?�?�� ? �?字?�对�??�

		for (int len = 0; len < byteCount(img); len += img->depth() / 8) {
			//byte aligned, skip padding bytes
			if ((len % x_align_size) >= (unsigned int)
			img->width()) {
				continue;
			}


			bit_point = convertImg(img);

			
			if (bit_point == 3) //alpha is true
			{
				alpha = img->constBits()[len + 3];
				color =
					 ((img->constBits()[len + 0] >> 3) << 11) + ((img->constBits()[len + 1] >> 2) << 5) + ((img->constBits ()[len + 2] >> 3) << 0);
			}
			else {
				alpha = img->constBits()[len + 3];
				color =
					 (((img->constBits()[len + 0] *alpha / 0xFF) >> 3) << 11) + (((img->constBits()[len + 1] *alpha / 0xFF) >> 2) << 5) + (((img->constBits()[len + 2] *alpha / 0xFF) >> 3) << 0);
			}
			if (((pos % 16) == 0) && (pos != last_pos)) {
				last_pos = pos;
				snprintf(buf, sizeof(buf), "\r\n\t");
				picture_data.insert(picture_data.size(), buf);
			}

			if (bit_point == 3) //alpha is true
			{
				snprintf(buf, sizeof(buf), "0x%02X, 0x%02X, 0x%02X, ", 
					alpha, (color >> 8) & 0xFF, (color >> 0) & 0xFF);
				pos += 3;
			}
			else {
				snprintf(buf, sizeof(buf), "0x%02X, 0x%02X, ", 
					(color >> 8) & 0xFF, (color >> 0) & 0xFF);
				pos += 2;
			}
			picture_data.insert(picture_data.size(), buf);
		}
		snprintf(buf, sizeof(buf), "\r\n};\r\n\r\n");
		picture_data.insert(picture_data.size(), buf);

		n++;
	}
	picture_file.write(picture_data);
	picture_file.close();
	//====================== picture_data.h file create =========
	picture_file.setFileName("picture_data.h");
	picture_file.open(QIODevice::ReadWrite);
	picture_file.resize(0);
	picture_data.resize(0);
	qDebug("set picture_data.h file");

	snprintf(buf, sizeof(buf), "/*************************************************************\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "** this file is all picture data head file\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "** by ZXHD\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "*************************************************************/\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "#ifndef _PICTURE_DATA_H\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "#define _PICTURE_DATA_H\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "\r\n\r\n");
	picture_data.insert(picture_data.size(), buf);

	n	= 0;
	//copy fileInfoList to fileInfo
	foreach (QString fileInfo, checkFilePathList) {
		QImage * img = new QImage();

		img->load(fileInfo);
		unsigned char bit_point = 0;

		if (STR_ALPHA_YES == ui->tableWidget->item(n, TABLE_COLUMN_ALPHA)->text()) {
			bit_point = 3;
		}
		else {
			bit_point = 2;
		}

		snprintf(buf, sizeof(buf), "extern const unsigned char %s_data[%d*%d*%d];\r\n", 
			checkFileNameList.at(n).toLocal8Bit().data(), 
			img->width(), img->height(), bit_point);
		picture_data.insert(picture_data.size(), buf);

		n++;
	}
	snprintf(buf, sizeof(buf), "\r\n\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "#endif// _PICTURE_DATA_H\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "\r\n");
	picture_data.insert(picture_data.size(), buf);
	picture_file.write(picture_data);
	picture_file.close();
	//====================== picture.c file create ==============
	picture_file.setFileName("picture.c");
	picture_file.open(QIODevice::ReadWrite);
	picture_file.resize(0);
	picture_data.resize(0);
	qDebug("set picture.c file");

	snprintf(buf, sizeof(buf), "/*************************************************************\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "** this file is all picture struct information source file\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "** by ZXHD\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "*************************************************************/\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "#include \"picture.h\"\r\n");
	picture_data.insert(picture_data.size(), buf);
	//if(Qt::Checked != ui->checkBox_flash->checkState())
	{
		snprintf(buf, sizeof(buf), "#include \"picture_data.h\"\r\n");
		picture_data.insert(picture_data.size(), buf);
	}
	snprintf(buf, sizeof(buf), "\r\n\r\n");
	picture_data.insert(picture_data.size(), buf);

	n	= 0;
	pos = 0;
	//copy fileInfoList to fileInfo
	foreach (QString fileInfo, checkFilePathList) {
		QImage * img = new QImage();

		img->load(fileInfo);

		snprintf(buf, sizeof(buf), "const picture_info_struct %s_info = {\r\n", 
			checkFileNameList.at(n).toLocal8Bit().data());
		picture_data.insert(picture_data.size(), buf);

		if (STR_SPI_FLASH == ui->tableWidget->item(n, TABLE_COLUMN_FLASH)->text())
		{
			snprintf(buf, sizeof(buf), "\t.addr = (const unsigned char *)0x%08x,\r\n", pos);
			if (STR_ALPHA_YES == ui->tableWidget->item(n, TABLE_COLUMN_ALPHA)->text()) {
				pos += img->width() *img->height() * 3;
			}
			else {
				pos += img->width() *img->height() * 2;
			}
		}
		else {
			snprintf(buf, sizeof(buf), "\t.addr = (const unsigned char *)%s_data,\r\n", 
				checkFileNameList.at(n).toLocal8Bit().data());
		}
		picture_data.insert(picture_data.size(), buf);

		snprintf(buf, sizeof(buf), "\t.width = %d,\r\n", img->width());
		picture_data.insert(picture_data.size(), buf);

		snprintf(buf, sizeof(buf), "\t.height = %d,\r\n", img->height());
		picture_data.insert(picture_data.size(), buf);

		if (STR_ALPHA_YES == ui->tableWidget->item(n, TABLE_COLUMN_ALPHA)->text()) {
			snprintf(buf, sizeof(buf), "\t.alpha = 1,\r\n");
		}
		else {
			snprintf(buf, sizeof(buf), "\t.alpha = 0,\r\n");
		}

		picture_data.insert(picture_data.size(), buf);

		if (STR_SPI_FLASH == ui->tableWidget->item(n, TABLE_COLUMN_FLASH)->text())
		{
			snprintf(buf, sizeof(buf), "\t.external_flag = 1,\r\n");
		}
		else {
			snprintf(buf, sizeof(buf), "\t.external_flag = 0,\r\n");
		}
		picture_data.insert(picture_data.size(), buf);

		snprintf(buf, sizeof(buf), "};\r\n\r\n");
		picture_data.insert(picture_data.size(), buf);

		n++;
	}
	picture_file.write(picture_data);
	picture_file.close();
	//====================== picture.h file create ==============
	picture_file.setFileName("picture.h");
	picture_file.open(QIODevice::ReadWrite);
	picture_file.resize(0);
	picture_data.resize(0);
	qDebug("set picture.h file");

	snprintf(buf, sizeof(buf), "/*************************************************************\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "** this file is all picture struct information head file\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "** by ZXHD\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "*************************************************************/\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "#ifndef _PICTURE_H\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "#define _PICTURE_H\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "\r\n\r\n");
	picture_data.insert(picture_data.size(), buf);

	snprintf(buf, sizeof(buf), "#define PIC_CRC16\t\t0x%04X\r\n", crc16 & 0xFFFF);
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "#define PIC_HEAD_SIZE\t16\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "#define PIC_OFFSET\t\t0x%08X\r\n", pic_offset);
	picture_data.insert(picture_data.size(), buf);

	snprintf(buf, sizeof(buf), "\r\n\r\n");
	picture_data.insert(picture_data.size(), buf);

	for (int i = 0; i < fileLenList_bin.count(); i++) {
		picture_data.insert(picture_data.size(), fileLenList_bin.at(i));
	}

	snprintf(buf, sizeof(buf), "\r\n\r\n");
	picture_data.insert(picture_data.size(), buf);

	picture_data.insert(picture_data.size(), "typedef struct\r\n");
	picture_data.insert(picture_data.size(), "{\r\n");
	picture_data.insert(picture_data.size(), "\tconst unsigned char *addr;\r\n");
	picture_data.insert(picture_data.size(), "\tconst unsigned short width;\r\n");
	picture_data.insert(picture_data.size(), "\tconst unsigned short height;\r\n");
	picture_data.insert(picture_data.size(), "\tconst unsigned char alpha;//0: no alpha, 1: has alpha, 2: point display, 3: 8bit(256 color), 4: alpha point.\r\n");
	picture_data.insert(picture_data.size(), "\tconst unsigned char external_flag;//0: mcu flash, 1: external spi flash or emmc.\r\n");
	picture_data.insert(picture_data.size(), "}picture_info_struct;\r\n");
	picture_data.insert(picture_data.size(), "\r\n\r\n");

	//copy fileInfoList to fileInfo
	foreach (QString fileInfo, checkFileNameList) {
		snprintf(buf, sizeof(buf), "extern const picture_info_struct %s_info;\r\n", 
			fileInfo.toLocal8Bit().data());
		picture_data.insert(picture_data.size(), buf);
	}
	snprintf(buf, sizeof(buf), "\r\n\r\n");
	picture_data.insert(picture_data.size(), buf);

	snprintf(buf, sizeof(buf), "#endif //_PICTURE_H\r\n");
	picture_data.insert(picture_data.size(), buf);
	snprintf(buf, sizeof(buf), "\r\n");
	picture_data.insert(picture_data.size(), buf);

	picture_file.write(picture_data);
	picture_file.close();
	//===========================================================
	QMessageBox::warning(this, 
		tr("?�?�"), 
		QString::number(checkFileNameList.count(), 10) +tr("张?�片?�件转?�成?�!"), 
		QMessageBox::Yes);
}

void MainWindow::on_pushButton_refresh_clicked()
{
	QString dir;

	dir = ui->lineEdit->text();

	//==============================================================
	QDir fromDir(dir);
	QStringList filters;

	filters.append("*.bmp");
	filters.append("*.png");

	filePathList.clear();
	fileNameList.clear();
	fileCompleteSuffixNameList.clear();
	scanData(fromDir, filters);
	//==============================================================
	ui->tableWidget->clear();
	ui->tableWidget->setRowCount(filePathList.count());
	ui->tableWidget->setColumnCount(TABLE_COLUMN_SUM);
	QStringList header;

	header << tr("?�?��?) << tr("?�外flash") << tr("?��?);
	ui->tableWidget->setHorizontalHeaderLabels(header);
	ui->tableWidget->horizontalHeader()->setStretchLastSection(true); //设置?�满表宽度
	ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
	for (int i = 0; i < filePathList.count(); i++) {
		if (fileCompleteSuffixNameList.at(i).indexOf("alpha", 0, Qt::CaseInsensitive) >= 0) {
			ui->tableWidget->setItem(i, TABLE_COLUMN_ALPHA, new QTableWidgetItem(STR_ALPHA_YES));
		}
		else {
			ui->tableWidget->setItem(i, TABLE_COLUMN_ALPHA, new QTableWidgetItem(STR_ALPHA_NO));
		}

		if (fileCompleteSuffixNameList.at(i).indexOf("mcu", 0, Qt::CaseInsensitive) >= 0) {
			ui->tableWidget->setItem(i, TABLE_COLUMN_FLASH, new QTableWidgetItem(STR_FORCE_MCU_FLASH));
		}
		else {
			ui->tableWidget->setItem(i, TABLE_COLUMN_FLASH, new QTableWidgetItem(STR_MCU_FLASH));
		}
		ui->tableWidget->setItem(i, TABLE_COLUMN_FILE, new QTableWidgetItem(filePathList.at(i)));

		//如?�子?�缀?�不?  alpha, point, mcu, pointAA 就报错
		if ((fileCompleteSuffixNameList.at(i).isEmpty() == false) && ((fileCompleteSuffixNameList.at(i).indexOf(".png", 0, Qt::CaseInsensitive) >
			 0) || (fileCompleteSuffixNameList.at(i).indexOf(".bmp", 0, Qt::CaseInsensitive) > 0)) &&
			 (fileCompleteSuffixNameList.at(i).indexOf("alpha", 0, Qt::CaseInsensitive) < 0) &&
			 (fileCompleteSuffixNameList.at(i).indexOf("point", 0, Qt::CaseInsensitive) < 0) &&
			 (fileCompleteSuffixNameList.at(i).indexOf("pAA", 0, Qt::CaseInsensitive) < 0) &&
			 (fileCompleteSuffixNameList.at(i).indexOf("mcu", 0, Qt::CaseInsensitive) < 0)) {
			qDebug("the file %s child suffix name is wrong\r\n", filePathList.at(i).toLatin1().data());
			QMessageBox::warning(this, 
				tr("�?��"), 
				tr("?�件后缀?�不? ?�") +filePathList.at(i).toLatin1().data(), 
				QMessageBox::Yes);
			return;
		}
	}
	ui->checkBox_alpha->setChecked(false);
	ui->checkBox_flash->setChecked(false);
	qDebug("file num %d", filePathList.count());

	//=====================================================================
	//========================= ? ?�bin?��?================================
	dir = ui->lineEdit_bin->text();
	if (dir.isEmpty()) {
		dir = ".//font//";							//don' uised curdir as outputs are bins
	}
	//==============================================================
	QDir fromDir_bin(dir);
	QStringList filters_bin;

	filters_bin.append("*.bin");

	filePathList_bin.clear();
	fileNameList_bin.clear();
	fileCompleteSuffixNameList_bin.clear();
	scanData_bin(fromDir_bin, filters_bin);
	//==============================================================
	ui->tableWidget_bin->clear();
	ui->tableWidget_bin->setRowCount(filePathList_bin.count());
	ui->tableWidget_bin->setColumnCount(1);
	QStringList header_bin;

	header_bin << tr("?��?);
	ui->tableWidget_bin->setHorizontalHeaderLabels(header_bin);
	ui->tableWidget_bin->horizontalHeader()->setStretchLastSection(true); //设置?�满表宽度
	ui->tableWidget_bin->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
	for (int i = 0; i < filePathList_bin.count(); i++) {
		ui->tableWidget_bin->setItem(i, 0, new QTableWidgetItem(filePathList_bin.at(i)));
	}
	qDebug("bin file num %d", filePathList_bin.count());
	//=====================================================================
}

void MainWindow::on_pushButton_dir_clicked()
{
	QString file_dir = ui->lineEdit->text();

	if (file_dir.isEmpty()) {
		file_dir = ".//";							//如?�� 径为空，?�设为当?�� 径
	}
	//返?�?�? ?�? � 径?�?�件名
	QString dir = QFileDialog::getExistingDirectory(this, tr("Open Directory"), 
		file_dir, 
		QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

	if (dir.isEmpty() == false) {
		ui->lineEdit->setText(dir);

		/* refresh the dir display. */
		on_pushButton_refresh_clicked();
	}
}

void MainWindow::on_checkBox_flash_clicked()
{
	for (int i = 0; i < ui->tableWidget->rowCount(); i++) {
		//don't change TABLE_COLUMN_FLASH if == STR_FORCE_MCU_FLASH
		if (0 == QString::compare(ui->tableWidget->item(i, TABLE_COLUMN_FLASH)->text(), 
			STR_FORCE_MCU_FLASH, Qt::CaseInsensitive)) {
			continue;
		}
		if (ui->checkBox_flash->isChecked()) {
			ui->tableWidget->item(i, TABLE_COLUMN_FLASH)->setText(STR_SPI_FLASH);
		}
		else {
			ui->tableWidget->item(i, TABLE_COLUMN_FLASH)->setText(STR_MCU_FLASH);
		}
	}
}
void MainWindow::on_checkBox_alpha_clicked()
{
	for (int i = 0; i < ui->tableWidget->rowCount(); i++) {
		if (ui->checkBox_alpha->isChecked()) {
			ui->tableWidget->item(i, TABLE_COLUMN_ALPHA)->setText(STR_ALPHA_YES);
		}
		else {
			ui->tableWidget->item(i, TABLE_COLUMN_ALPHA)->setText(STR_ALPHA_NO);
		}
	}
}
void MainWindow::on_tableWidget_cellClicked(int row, int column)
{
	if (column == TABLE_COLUMN_ALPHA) {
		if (STR_ALPHA_YES == ui->tableWidget->item(row, column)->text()) {
			ui->tableWidget->item(row, column)->setText(STR_ALPHA_NO);
		}
		else {
			ui->tableWidget->item(row, column)->setText(STR_ALPHA_YES);
		}
	}
	else if (column == TABLE_COLUMN_FLASH) {
		if (STR_MCU_FLASH == ui->tableWidget->item(row, column)->text()) {
			ui->tableWidget->item(row, column)->setText(STR_SPI_FLASH);
		}
		else {
			ui->tableWidget->item(row, column)->setText(STR_MCU_FLASH);
		}
	}
}
void MainWindow::on_pushButton_bin_clicked()
{
	QString file_dir = ui->lineEdit_bin->text();

	if (file_dir.isEmpty()) {
		file_dir = ".//";							//if path == "", change to current dir
	}
	//return full path file name
	QString dir = QFileDialog::getExistingDirectory(this, tr("Open Directory"), 
		file_dir, 
		QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

	if (dir.isEmpty() == false) {
		ui->lineEdit_bin->setText(dir);
		/* refresh the dir display. */
		on_pushButton_refresh_clicked();
	}
}
